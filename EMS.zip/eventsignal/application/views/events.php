<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Event-Management</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link  href="/eventsignal/assets/css/pumpy.css" rel="stylesheet" >

</head>
<body>
<!-- 
<div class = "navbar navbar-default navbar-fixed-top" >
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand mx-5" href="index.html">EVS</a>

            <button type="button" class="navbar-toggle">
                <span class = "sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

        </div>
        <div class="collapse navbar-collapse navbar-right" >
            <ul class="nav navbar-nav">
                <li class="nav-item ">
                    <a class="nav-link" href="#">BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEARN MORE</a>
                </li>
            </ul>

            <span class="padded"><a class="btn btn-outline-red" href="">Login</a></span>
            <span class="padded"><a class="btn btn-red" href="">Create Event</a></span>
        </div>
    </div>
</div> -->

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 advert">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 trend">
                        <div class="row">
                            <div class="col-md-4 hints">
                                <span><?php echo date("F", strtotime($records[0]->e_startdate));?></span>
                                <br/>
                                <span><?php echo date("jS, Y", strtotime($records[0]->e_startdate));?></span>
                                <br/>
                                <br/>
                                <h4><?php echo $records[0]->e_name;?></h4>
                                <br>
                                <p>By <?php echo $records[0]->e_org_name;?></p>
                            </div>

                            <div class="col-md-8 browse event-card__image">
                                <!-- <img src="/eventsignal/assets/images/IMG_8876.jpg">  -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Over Lay Part begins-->
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 inform" >
                <div class="row">
                    <div class="col-md-12 laffbord">
                        <div class="row">
                            <div class="col-md-4 laff">
                                <button class="btn btn-success prosbut">REGISTER FOR EVENT</button>
                            </div>
                            <div class="col-md-8 laffloud">
                                <span class="glyphicon glyphicon-share"></span>
                                <span class="glyphicon glyphicon-bookmark"></span>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row trying">
                    <div class="col-md-6 col-md-offset-1">
                       <h4>Description</h4>
                        <p class="board"><p><?php echo $records[0]->e_desc;?>
                        </p>
                        </p>
                        
                       
                    </div>
                    <div class="col-md-4 col-md-offset-1">
                        <h4>Date and Time </h4>
        <span class="board"><h5 class="smaller"><?php echo date("F jS, Y", strtotime($records[0]->e_startdate)).','. $records[0]->e_starttime. ' -';?></h5></span><br>
                        <span class="board"><h5 class="smaller"><?php echo date("F jS, Y", strtotime($records[0]->e_enddate)).','. $records[0]->e_endtime;?></h5></span><br>
                        <!-- <span class="board">VAT</span><br>
                        <span class="calender"><a href="#">Add to Calender</a> </span>
 -->
                    <div class="space-24"></div>
                    <br>
                    <h4>Location</h4>
                    <span class="board"><h5><?php echo $records[0]->e_location;?></h5></span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 viewmap">
                        <button class="btn viewbut">View Map</button>
                    </div>
                </div>

            </div>
        </div>

        <div class="container">

        </div>
    </div><!--Over Lay Part ends-->

    <!--Browse By categories begins-->

       <!--Browse By categories ends-->

    <!--Footer begins-->
    <div class="row">
        <div class="col-md-12 footer" id="botts">
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-offset-1">
                        <span id="fsign">EVS</span><span id="copy">Copyright &copy; 2017 EVS</span>
                    </div>
                </div>
                <div class="col-md-8 elink">
                    <div id="got" class="col-md-offset-7">
                        <span class="ink"> <a href="" class="">FAQ</a></span>
                        <span class="ink"><a href="" class="">HELP</a></span>
                        <span class="ink"><a href="" class="">PRIVACY</a></span>
                        <span class="ink"><a href="" class="">TERMS</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--<div id="topN"><div class="fine"><a href="#tops">up</a></div></div>
    <div id="bottF"><div class="fine"><a href="#botts">down</a></div></div>-->

</div>
<script src="js/index.js"></script>
</body>
</html>