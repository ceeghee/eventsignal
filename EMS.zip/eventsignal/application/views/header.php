<!DOCTYPE html>
<html lang="" ng-app="evs">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Management System</title>

    <script  src="assets/js/bootstrap.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="/eventsignal/assets/css/bootstrap.css" rel="stylesheet">
    <link href="/eventsignal/assets/css/style.css" rel="stylesheet">
    <link  href="/eventsignal/css/pumpy.css" rel="stylesheet" >

</head>

<body>

    <!-- navigation bar begins here -->
    <nav class="navbarz navbarz-expand-md fixed-top ">
        <a class="navbar-brand mx-5" href="http://localhost:8012/eventsignal/">Eventsignal</a>
        <button class="navbarz-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarzCollapse" aria-controls="navbarzCollapse" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbarz-toggler-icon"></span>
                </button>
        <div class="collapse navbarz-collapse mr-5" id="navbarzCollapse">
            <ul class="navbarz-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEARN MORE</a>
                </li>
                <?php if($this->session->userdata('username')){ $username=$this->session->userdata('username')?>
                <li class="nav-item">
                    <a class="nav-link" href="#"><?php echo strtoupper($username);?></a>
                </li>

               <!--  <li class="nav-item">
                    <a class="btn btn-outline-red" href="login">Logout</a>
                </li> -->
                
            </ul>

            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/logout">Logout</a> <span>
            <?php }else{?>
            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/login">Login</a> <span>
            <?php }?>
            <span class="padded"><a class="btn btn-red" href="/eventsignal/create">Create Event</a></span>
        </div>
    </nav>