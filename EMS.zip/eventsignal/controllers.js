	// (function(){
 angular.module("evsControllers",[]);

	// app.controller("mainController",function(){
	// 	console.log("hello from controllers");
	// });
	// })();
	// .config(function(){
	// 	console.log("helo");
	// });
			

			