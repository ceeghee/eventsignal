
<?php


class Main extends CI_MODEL{

		public function test_model(){

			echo "I am main Model";
		}

		public function insert_data($data){

			$this->db->insert("projects",$data);
		}

		public function get_data(){

			//$query =	$this->db->get("projects");
			$query= $this->db->query("SELECT * From projects order by id asc");
				return $query;

		}

		public function get_user_data($email){

			//$query =	$this->db->get("projects");
			$query= $this->db->query("SELECT email from users where email='$email' order by email desc limit 1");
				return $query;

		}

		public function delete_data($id){

			/*$this->db->where("id",$id);
			$this->db->delete("projects");
*/
			$query= $this->db->query(" DELETE  from projects where id='$id' ");
			return $query;
		}

		public function login2($email,$pass){
			$this->db->select('email','password');
			$this->db->from('users');
			$this->db->where('email',$email);
			$this->db->where('password',$pass);
			$query=$this->db->get();
			if($query->num_rows()==1){
				return true;
			}
			else{
				return false;
			}
		}
		public function signup($data){
			return $this->db->insert('users',$data);
		}
		public function saveFeed($data){
			return $this->db->insert('feebacks',$data);
		}

		public function create_event($data){
			return $this->db->insert('events',$data);
		}
		public function create_event_ticket($data){
			return $this->db->insert('events_tickets',$data);
		}

		public function authUser($user){
			$this->db->select('username');
			$this->db->from('users');
			$this->db->where('username',$user);
			$query=$this->db->get();
			if($query->num_rows()==1){
				return true;
			}
			else{
				return false;
			}
		}

		public function authEmail($email){
			$this->db->select('email');
			$this->db->from('users');
			$this->db->where('email',$email);
			$query=$this->db->get();
			if($query->num_rows()==1){
				return true;
			}
			else{
				return false;
			}
		}
		public function login($email,$password){
			$query=$this->db->where(['email'=>$email,'password'=>$password])
							->get('users');
				if($query->num_rows()>0){
					return $query->row();
				}
		}

		public function getEvents(){
			$current = strtotime(date("02-11-2017"));
			$limit= '02-11-2017';
			$this->db->select('*');
			$this->db->from('events');
			$this->db->limit('11');
			$this->db->order_by("event", "DESC");
			$query= $this->db->get();
			return $query ->result();	
	// 			$current = strtotime(date("d-m-Y"));
// $query= $this->db->query("SELECT * FROM 
// 	events WHERE  floor(((e_startdate-'$current')/(60*60*24))>0)  ORDER BY event DESC LIMIT 6");
// 			return $query->result();
		}

		public function getFeedBacks(){
			$this->db->select('*');
			$this->db->from('feebacks');
			$this->db->limit('10');
			$this->db->order_by("feed_id", "DESC");
			$query= $this->db->get();
			return $query ->result();	
		}


		public function listEvents($e_id){
			$this->db->select('*');
			$this->db->from('events');
			$this->db->where('event',$e_id);
			$query=$this->db->get();
			if($query->num_rows()==1){
				return $query ->result();	
			}
			else{
				return false;
			}
		}

		public function get_event_ticket_et($eventid){
			$this->db->select('*');
			$this->db->from('events_tickets');
			$this->db->where('event_id',$eventid);
			$query=$this->db->get();
			if($query->num_rows()==1){
				return $query ->result();	
			}
			else{
				return false;
			}
		}

		public function _singleEvent(){
			$this->db->select('event');
			$this->db->from('events');
			$this->db->limit('1');
			$this->db->where('ticket_id','');
			$this->db->order_by("event", "DESC");
			$query=$this->db->get();
			if($query->num_rows()==1){
				return $query ->result();	
			}
			else{
				return false;
			}
		}
}