
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 special" id="tops">
            <span> FIND YOUR NEXT EXPERIENCE </span>
        </div>
    </div>
    <!--Over Lay Part begins-->
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-md-offset-0 info" >
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 find">
                        <form class="form-inline inline">
                            <div class="form-group">
                                <input type="text" class = "form-control" name="events" id = "events" placeholder="Search events or categories" required>
                            </div >

                            <div class="form-group">
                                <span class="glyphicon glyphicon-map-marker"></span>
                                <input type="text" class = "form-control" name="location" id = "location" placeholder="Location" required>


                            </div>

                            <div class="form-group">
                             <span class="glyphicon glyphicon-calendar"></span>
                                <input type="text" class = "form-control" name="date" id = "date" placeholder="Date" required>


                            </div>

                            <div class="form-group">
                                <input type="submit" class="btn btn-danger" value="SEARCH" name = "search" id="but">
                            </div>

                        </form>
                    </div>
                </div>
                <div class="row done">
                    <div class="col-md-8 col-md-offset-3">
                        <form class="form-inline">
                            <div class="form-group">
                                <label for="pop">Population Event in</label>
                                <input type="text" class = "form-control" name="pop" id = "pop" placeholder="Enter city or location">

                            </div>
                        </form>
                    </div>
                </div>
                <div class="container">
                    <div class="row  fix">
                        <div class="col-md-12">
                            <!-- looping starts ere -->
                            <?php if(count($records)):?>
                                <?php foreach($records as $record):?>
                                    <!-- <?php print_r($record);?> -->
                                    <?php  $date    = strtotime($record->e_startdate);    
                                         $datediff = $date - strtotime(date("d-m-Y"));
                                         $difference = floor($datediff/(60*60*24));?>
                                         <?php  if($difference >=1):?>

                            <div class="col-md-4 ">
                            <a href="/eventsignal/events/e/<?php echo $record->event;?>/<?php echo $record->e_name;?>">
                                <div class="obj1" data-toggle="modal" data-target="#modal1">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <img src="<?php echo $record->e_image;?>" class="pictures">
                                        </div>
                                    </div>

                                    <div class="below">
                                            <br>
                                         <div  class="col-md-10 col-md-offset-1">
                                        <span class="event-card__details"><?php $date =  $record->e_startdate;
                                         echo date("F jS, Y", strtotime($date)) . " " . $record->e_starttime; ?>
                                     </span>
                                            </div> 
                                        <div class="row" >
                                            <div class="col-md-12 help">
                                            <div class="row" >
                                                 <div class="col-md-10 col-md-offset-1">
                                                    <font color="#F40B0B" size="3">
                    <span class="eve"><?php $title = (strlen($record->e_name)) > 50 ? substr($record->e_name,0,45).'...' :$record->e_name; echo $title?>
                    </span>
                                                   <!--  <span class="bolder">Advancing E-Learing in Schools at large around</span>
 -->                                                  </font>
                                                    </div>
                                            </div>

                                        </div>
                                      </div>
                                        <div class="row">
                                            <div class="col-md-10 col-md-offset-1 street">
                                                <span><?php echo $record->e_location;?></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-10 col-md-offset-1">
                                                <div class="hori"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-11 col-md-offset-1 site">
                                                <span>#Tech #News #Students</span>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </a>
                            </div> <!-- looping card ere -->












                             <?php else:?>
                        <?php endif;?>
                        <?php endforeach;?>
                    <?php else:?>
                        <p> No Post Found</p>
                    <?php endif;?>
                        </div>

                    </div>

                

                </div>

                <div class="row">
                    <div class="col-md-5 col-md-offset-5 bb">
                        <input type="submit" class="btn see" value="See More" />
                    </div>
                </div>


            </div>
        </div>


    </div><!--Over Lay Part ends-->

    <!--Browse By categories begins-->
    <div class="container">

        <div class="row">
            <div class="col-md-7 col-md-offset-4 ohh">
                <span class="btw">BROWSE BY CATEGORIES</span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="one">
                    <span class="sign">MUSIC</span>
                </div>
            </div>
            <div class="col-md-5 " >
                <div class="two">
                    <span class="sign">WEDDING</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5" >
                <div class=" tree">
                    <span class="sign">ART</span>
                </div>
            </div>
            <div class="col-md-7" >
                <div class=" four">
                    <span class="sign">PARTY</span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7 ">
                <div class=" five">
                    <span class="sign">TECH MEETUP</span>
                </div>
            </div>
            <div class="col-md-5" >
                <div class=" six">
                    <span class="sign">SPORT</span>
                </div>
            </div>
        </div>
    </div><!--Browse By categories ends-->






    <!--Footer begins-->
    <div class="row">
        <div class="col-md-12 footer" id="botts">
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-offset-1">
                        <span id="fsign">EVS</span><span id="copy">Copyright &copy; 2017 EVS</span>
                    </div>
                </div>
                <div class="col-md-8 elink">
                    <div id="got" class="col-md-offset-7">
                        <span class="ink"> <a href="" class="">FAQ</a></span>
                        <span class="ink"><a href="" class="">HELP</a></span>
                        <span class="ink"><a href="" class="">PRIVACY</a></span>
                        <span class="ink"><a href="" class="">TERMS</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--<div id="topN"><div class="fine"><a href="#tops">up</a></div></div>
    <div id="bottF"><div class="fine"><a href="#botts">down</a></div></div>-->

</div>
<script src="assets/js/index.js"></script>
<!-- </body>
</html> -->