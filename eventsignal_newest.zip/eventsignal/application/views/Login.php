
    <!-- navigation bar begins here -->

       <!-- Start my ng-view from here -->
       <input type="text" value="my text area"/>
<div class="header">
        	


         
        <div class="header-contentl" ng-controller="startController">
           
          <div class="space-30"></div>
            <div class="container eventgrid">
              <div class="event-grid" >
                  <br><br><br><br><br><br><br><br><br><br>
                    <div class="container">
                        
                       	<div class="container text-center">
                       	<!-- <a class="navbar-brand mx-5 align-center" href="#">EVS</a> -->
                       	<div class=""><h3> Welcome Back</h3></div>
                        <?php if(!isset($_SESSION['create_repo'])){?>
                       	<div class=""> Enter your details to  Sign in</div>
                      <?php } else{?>
                        <div class=""> You need to be signed in to create events</div>
                        <?php }?>
                        <?php if(!isset($_SESSION['gto_feedback'])){?> 
                     <div class=""> Enter your details to  Sign in</div>
                       <?php } else{?> 
                        <div class="alert alert-danger col-sm-12 col-lg-6 col-lg-offset-3">
                         You need to be signed in to create feedbacks
                     </div>
                         <?php }?>
<!--                       <div class="alert alert-danger"><?php echo validation_errors('owk');?></div>
 -->                      <?php echo '<strong>'.validation_errors().'</strong>';?>
                          <?php if($msg=$this->session->flashdata('loginresponse')): ?>

                             <div class="alert alert-danger col-sm-12 col-lg-6 col-lg-offset-3"><strong><?php echo $msg;?></strong></div>

                           <?php endif ?>
                       	
              <form class="form-row popularForm" action="" method="post">
                         <label for="password" class="popular"></label>
                            <div class="col-sm-12 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3">
                              
                            <input type="text" id="password" name="Email" class="col-md-4 mx-2 form-control" placeholder="Email" required>
                            <br>
                            <br>
                            <label for="password" class="popular"></label>
                            <input type="password" id="password" name="Password" class="col-md-4 mx-2 form-control" placeholder="Password" required>
                            <br>

                    <input type="hidden" id="password" name="submit" value="HIDDEN" class="col-md-4 mx-2 form-control" hidden>
                            
                        <input type="submit" class="btn btn-outline-red" value="Login" name="login"/>     
                            </div>


                        </form>
                    	</div>
                      <br>
                    		 <div align="center">
                            <!-- <a class="btn btn-outline-red" href="">Get Started</a> -->
                            <label>Don't Have an account yet?</label>
                            <a href="signup">
                            <button class="btn btn-outline-red" ng-click='getDetails()'>Sign Up</button>
                            </a>     
                        </div>
                    
                        </div>
                </div>
                
            </div>
            <!-- <br>
            <br>
                <footer>
                    <h1 class="footbrand col-md-1">EVS</h1>
                </footer> -->
            </div> 
            
            
 </div>

      
        </div>
                <script src="app/angular.js"></script>
            <script src="app/angular-route.js"></script>
             <script src="app/apps.js"></script>
            <script src="app/controllers.js"></script>
            <script src="assets/js/jquery-3.2.1.js"></script>
            
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/main.js"></script>
            

            <!-- Bootstrap JavaScript -->
            <script src="assets/js/bootstrap.js">
            </script>
</body>

</html>