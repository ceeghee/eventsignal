
    <!-- navigation bar begins here -->

       <!-- Start my ng-view from here -->
       <input type="text" value="my text area"/>
<div class="header">
            


         
        <div class="header-contentl" ng-controller="startController">
           

            <div class="container eventgrid">
              <div class="event-grid" >
                  <br><br><br><br><br><br><br><br><br><br>
                    <div class="container">
                        
                        <div class="container text-center">
                            <!-- <div align="center">
                                
                        <a class="navbar-brand mx-5" href="#">EVS</a>
                            </div>
                        <br>
 -->                        <div class=""><h3> Let's get started</h3></div>
                        <div class=""> Enter your details to  Sign up</div>
                            
<!--                       <div class="alert alert-danger"><?php echo validation_errors('owk');?></div>
 -->                      <?php echo '<strong>'.validation_errors().'</strong>';?>
                          <?php if($msg=$this->session->flashdata('response')): ?>

                             <div class="alert alert-success col-sm-12 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3"><?php echo $msg;?>
                                <br>
                               <a href="login" class="bolder"> Click to Login Now</a>
                             </div>
                           <?php endif ?>
                        
              <form class="form-row popularForm" action="" method="post">
                <div align="center" class="col-sm-12 col-md-6 col-md-offset-3 col-lg-6 col-lg-offset-3"> 
                    
                         <label for="username" class="popular"></label>
                            <input type="text" id="username" name="username" class="col-md-4 mx-2 form-control" placeholder="Username" required>
                            <br><br>
                            <label for="email" class="popular"></label>
                            <input type="text" id="password" name="email" class="col-md-4 mx-2 form-control" placeholder="Email" required>
                            <br><br>
                            <label for="password" class="popular"></label>
                            <input type="password" id="password" name="password" class="col-md-4 mx-2 form-control" placeholder="Password" required>
                            <br><br>
                            <label for="password" class="popular"></label>
                            <input type="password" id="password" name="confirmpassword" class="col-md-4 mx-2 form-control" placeholder="Confirm Password" required>
                            <br><br>
                            <input type="hidden" id="password" name="submit" value="HIDDEN" class="col-md-4 mx-2 form-control" hidden>
                            
                        <input type="submit" class="btn btn-outline-red" value="Sign Up" name="signup"/>     


                </div>
                        </form>
                        </div>
                        <br>
                             <div align="center">
                            <!-- <a class="btn btn-outline-red" href="">Get Started</a> -->
                            <label>Already Have an Account?</label>
                            <a href="login">
                            <button class="btn btn-outline-red" ng-click='getDetails()'>Sign in</button>
                            </a>     
                        </div>
                    
                        </div>
                </div>
                
            </div>
            
            </div> 
            
            
 </div>

      
        </div>
                <script src="app/angular.js"></script>
            <script src="app/angular-route.js"></script>
             <script src="app/apps.js"></script>
            <script src="app/controllers.js"></script>
            <script src="assets/js/jquery-3.2.1.js"></script>
            
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/main.js"></script>
            

            <!-- Bootstrap JavaScript -->
            <script src="assets/js/bootstrap.js">
            </script>
</body>

</html>