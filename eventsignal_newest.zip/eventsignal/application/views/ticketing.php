
<!DOCTYPE html>
<html lang="en" ng-app="evs" ng-cloak>
 <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>Eventsignal create a new event</title>

        <meta name="description" content="Common form elements and layouts" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

        <!-- bootstrap & fontawesome -->
         <link href="/eventsignal/assetz/css/style.css" rel="stylesheet">
     <!--    <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="assetz/css/bootstrap.min.css" /> -->
        <link rel="stylesheet" href="assetz/font-awesome/4.5.0/css/font-awesome.min.css" />

        <!-- page specific plugin styles -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/jquery-ui.custom.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/chosen.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-datepicker3.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-timepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/daterangepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-datetimepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-colorpicker.min.css" />

        <!-- text fonts -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/fonts.googleapis.com.css" />

        <!-- ace styles -->
        <!-- <link rel="stylesheet" href="/eventsignal/assetz/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" /> -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace.unmin.css" class="ace-main-stylesheet" id="main-ace-style" />

        <!--[if lte IE 9]>
            <link rel="stylesheet" href="assetz/css/ace-part2.min.css" class="ace-main-stylesheet" />
        <![endif]-->
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace-skins.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace-rtl.min.css" />


    </head>

<body class="no-skin">
    
                        <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 ">
                            
                        <div class="hr hr-18 dotted hr-double"></div>
                               <div class="align-center">
                                  <h3>EVENT TICKET BOOKING</h3>
                               </div> 
                        <div class="hr hr-18 dotted hr-double"></div>

                         <div layout-gt-sm="row"  layout-align="center" flex="100">
                    <div class="widget-box">
                      <div class="widget-headers widget-header-round" align="center"">
                        <!-- <h4 class="widget-title lighter">
                          <i class="ace-icon fa fa-star orange"></i>
                          Popular Domains
                        </h4> -->
                            <h4 class="widget-title lighter">TICKET DETAILS</h4>


                        <div class="widget-toolbar">
                          <a href="#" data-action="collapse">
                            <i class="ace-icon fa fa-chevron-up"></i>
                          </a>
                        </div>
                      </div>

                      <div class="widget-body">
                        <div class="widget-main no-padding">
                          <table class="table table-bordered "><!-- table-striped -->
                         

                            <tbody>
                              <tr>
                                <td>TICKET TYPE</td>

                                <td>
                                  
                                    <u class="black">
                                        <?php echo $records[0]->type;?>
                                   </u>
                                </td>

                              </tr>

                              <tr>
                                <td>Price</td>

                                <td>
                                  <b class="black"> 0 USD</b>
                                </td>
                              </tr> 
                               <tr>
                                <td>TICKET TITLE</td>

                                <td>
                                  <b class="black">  <?php echo $records[0]->ticket_title;?></b>
                                </td>
                              </tr>

                              <tr>
                                <td>DESCRIPTION</td>

                                <td>
                                  <b class="black"> <?php echo $records[0]->ticket_description;?></b>
                                </td>

                                <!-- <td class="hidden-480">
                                  <span class="label label-danger arrowed">pending</span>
                                </td> -->
                              </tr>


                              <tr>
                                <td>TICKET PER HEAD</td>
                                
                                <td>
                                  <b class="black"><?php echo $records[0]->ticket_minimum;?></b>
                                </td>
                              </tr>
                              <tr>
                                <td>QUANTITY AVAILABLE</td>

                                <td>
                                  <b class="black"><?php echo $records[0]->quantity;?></b>
                                </td>
                              </tr>
                              <tr>
                                <td>TICKET SALE ENDS</td>

                                <td>
                                  <b class="black"><?php echo $records[0]->ticket_end;?> <?php echo $records[0]->ticket_end_time;?> </b>
                                </td>
                              </tr>
                              <tr>
                                <td class="orange">Enter your details below to register for this event</td>

                              </tr>
                            </tbody>
                          </table>
                        </div><!-- /.widget-main -->
                      </div><!-- /.widget-body -->
                    </div><!-- /.widget-box -->
                  </div><!-- /.col -->

                          <div class="space-10"></div>
                        <div class="widget-body">
                                        <div class="widget-main">
                                            <h4 class="header blue lighter bigger">
                                                <i class="ace-icon fa fa-coffee green"></i>
                                                Please Fill This Form To Book Ticket (Note: you need to be signed in to book tickets)
                                            </h4>

                                            <div class="space-6"></div>

                                            <form>
                                                <fieldset>
                                                    <label class="block clearfix">
                                                      First Name
                                                        <span class="block input-icon input-icon-right">
                                                      <input type="text" class="form-control" placeholder="First Name" />
                                                            <i class="ace-icon fa fa-user"></i>
                                                        </span>
                                                    </label>

                                                    <label class="block clearfix">
                                                      Last Name
                                                        <span class="block input-icon input-icon-right">
                                                        <input type="text" class="form-control" placeholder="Last Name" />
                                                            <i class="ace-icon fa fa-lock"></i>
                                                        </span>
                                                    </label>
                                                     <label class="block clearfix">
                                                      Email
                                                        <span class="block input-icon input-icon-right">
                                                        <input type="text" class="form-control" placeholder="Last Name" />
                                                            <i class="ace-icon fa fa-lock"></i>
                                                        </span>
                                                    </label>

                                                    <label class="block clearfix">
                                                      Number of Tickets
                                                        <span class="block input-icon input-icon-right">
                                                        <input type="number" class="form-control" placeholder="Ticket Quantity" />
                                                            <i class="ace-icon fa fa-lock"></i>
                                                        </span>
                                                    </label>

                                                    <div class="space"></div>

                                                    <div class="clearfix">

                                                        <button type="submit" class="width-35 pull-right btn btn-sm btn-primary">
                                                            <i class="ace-icon fa fa-key"></i>
                                                            <span class="bigger-110">Book Ticket</span>
                                                        </button>
                                                    </div>

                                                    <div class="space-4"></div>
                                                </fieldset>
                                            </form>

                                            
                                        </div><!-- /.widget-main -->

                                      
                                    </div><!-- /.widget-body -->
                                    <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="space-24"></div>
                        </div>
                        
                        <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="space-24"></div>













 <script src="assetz/js/jquery-ui.custom.min.js"></script>
        <script src="assetz/js/jquery.ui.touch-punch.min.js"></script>
        <script src="assetz/js/chosen.jquery.min.js"></script>
        <script src="assetz/js/markdown.min.js"></script>
        <script src="assetz/js/bootstrap-markdown.min.js"></script>
        <script src="assetz/js/jquery.hotkeys.index.min.js"></script>
        <script src="assetz/js/bootstrap-wysiwyg.min.js"></script>
        <script src="assetz/js/bootbox.js"></script>
        <script src="assetz/js/spinbox.min.js"></script>
        <script src="assetz/js/bootstrap-datepicker.min.js"></script>
        <script src="assetz/js/bootstrap-timepicker.min.js"></script>
        <script src="assetz/js/moment.min.js"></script>
        <script src="assetz/js/daterangepicker.min.js"></script>
        <script src="assetz/js/bootstrap-datetimepicker.min.js"></script>
        <script src="assetz/js/bootstrap-colorpicker.min.js"></script>
        <script src="assetz/js/jquery.knob.min.js"></script>
        <script src="assetz/js/autosize.min.js"></script>
        <script src="assetz/js/jquery.inputlimiter.min.js"></script>
        <script src="assetz/js/jquery.maskedinput.min.js"></script>
        <script src="assetz/js/bootstrap-tag.min.js"></script>
</body>
</html>
