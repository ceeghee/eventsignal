<!DOCTYPE html>
<html lang="" ng-app="evs">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Management System</title>

    <!-- <script  src="assets/js/bootstrap.min.js"></script>
    <link href="/eventsignal/assets/css/bootstrap.css" rel="stylesheet">
    <link href="/eventsignal/assets/css/style.css" rel="stylesheet">
    <link  href="/eventsignal/css/pumpy.css" rel="stylesheet" > -->
    <script  src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-3.1.0.min.js"></script>
    <script  src="assets/js/bootstrap.js"></script>
    <!-- <script src="js/angular.min.js"></script> -->
    <link  href="/eventsignal/assets/css/bootstrap.min.css" rel="stylesheet" >
    <link  href="/eventsignal/assets/css/bootstrap.css" rel="stylesheet" >
    <link  href="/eventsignal/assets/css/pumpy.css" rel="stylesheet" >

</head>

<body>

    <!-- navigation bar begins here -->
    <div class = "navbar navbar-default navbar-fixed-top" >
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand mx-5" href="http://localhost:8012/eventsignal/">Eventsignal</a>

            <button type="button" class="navbar-toggle">
                <span class = "sr-only"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

        </div>
        <div class="collapse navbar-collapse navbar-right" >
            <ul class="nav navbar-nav">
                <li class="nav-item ">
                    <a class="nav-link" href="allevents">
                    BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEARN MORE</a>
                </li>
                 <li class="nav-item">
                    <a class="nav-link" href="/eventsignal/feedback">FEEDBACKS</a>
                </li>
            </ul>

            <?php if($this->session->userdata('username')){ $username=$this->session->userdata('username')?>
                <!-- <li class="nav-item"> -->
                    <span class="padded">
                        
                    <a class="btn btn-outline-red" href="/eventsignal/user">
                         <font color="#F40B0B" size="2">
                                <?php echo strtoupper($username);?>
                              </font>
                            
                        </a>
                    </span>
                <!-- </li> -->
            </ul>

            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/logout">Logout</a> </span>
            <?php }else{?>
            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/login">Login</a> </span>
            <!-- <span class="padded"><a class="btn btn-outline-red" href="">Login</a></span> -->

            <?php }?>
            <span class="padded"><a class="btn btn-red" href="/eventsignal/create">Create Event</a></span>
            
        </div>
    </div>
</div>
    <!-- <nav class="navbarz navbarz-expand-md fixed-top ">
        <a class="navbar-brand mx-5" href="http://localhost:8012/eventsignal/">Eventsignals</a>
        <button class="navbarz-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarzCollapse" aria-controls="navbarzCollapse" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbarz-toggler-icon"></span>
                </button>
        <div class="collapse navbarz-collapse mr-5" id="navbarzCollapse">
            <ul class="navbarz-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEARN MORE</a>
                </li>
                <?php if($this->session->userdata('username')){ $username=$this->session->userdata('username')?>
                <li class="nav-item">
                    <a class="nav-link" href="#"><?php echo strtoupper($username);?></a>
                </li>
            </ul>

            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/logout">Logout</a> <span>
            <?php }else{?>
            <span class="padded"><a class="btn btn-outline-red" href="/eventsignal/login">Login</a> <span>
            <?php }?>
            <span class="padded"><a class="btn btn-red" href="/eventsignal/create">Create Event</a></span>
        </div>
    </nav> -->