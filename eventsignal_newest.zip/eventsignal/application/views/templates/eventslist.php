<!-- Start my ng-view from here -->
<div class="header">
        <img class="embed-responsive header" src="assets/images/events-heavenly-header.jpg" alt="">
        
        <div class="header-content" ng-controller="homeController">
            <h0>FIND YOUR NEXT EXPERIENCE</h0>
            <div class="container  search-form-bg">
                <form class="search-form form-row">
                    <label for="inputEvent" class="sr-only">Search events or categories</label>
                    <input type="text" id="inputEvent" class="mx-2 form-item form-control" placeholder="Search events or categories" required>
                    <label for="inputLocation" class="sr-only">Location</label>
                    <input type="text" id="inputLocation" class="mx-2 form-control" placeholder="Location" required>
                    <label for="inputLocation" class="sr-only">Date</label>
                    <input type="text" id="inputDate" class="mx-2 form-control" placeholder="Date" required>

                    <span class="search-button">
                    <button class="btn btn-danger btn-search" type="submit">{{welcome}}</button>
                    </span>
                </form>
            </div>
            <div class="container eventgrid">
              
                <div class="event-grid" ng-controller="FinanceController">
                    <div class="container text-center">
                        <form class="form-row popularForm">
                            <label for="inputLocation" class="popular">Popular Events in: </label>
                            <input type="text" id="inputLocation" class="searchLocation col-md-4 mx-2 form-control" placeholder="Enter city or Location" required>
                        </form>
                    </div>
                    <div class="container">
                        <div class="row card-group">
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event would be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event woild be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event woild be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="row card-group">
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event woild be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event woild be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="event-card">
                                <a href="">
                                    <div class="event-card__image">


                                        <img src="assets/images/no1.jpg" alt="event picture" width="100%" class="emebed-responsive">
                                    </div>
                                    <div class="event-card__caption">
                                        <div class="event-card__name"> <span>The main location</span>, <span>Nigeria</span> </div>
                                        <div class="event-card__location">The address</div>
                                        <div class="line-down">

                                        </div>
                                        <div class="event-card__details">
                                            This is where the details for the event woild be, and the details will lead to the event main page
                                        </div>
                                        <div class="line-down">

                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="see-more">
                            <span class="padded"><a class="btn btn-outline-red" href="">SEE MORE</a> <span>    
                        </div>
                        </div>
                </div>
            </div>
            <br>
            <br>
            <div class="trending-categories container">
                <div class="big-headline text-center">
                    <h2>Browse by Categories</h2>
                </div>
                <div class="category-container">
                        <div class="left">
                            <div class="left__top">
                                <a href="">
                                    <img src="assets/images/event-music.jpg" alt="MUSIC" width="100%">

                                    <div class="category__caption">
                                        <h3>MUSIC</h3>
                            </div>
                            </a>
                        </div>
                        <div class="left__bottom">
                            <a href="">
                                <img src="assets/images/share_artsevent.jpg" alt="ART" width="100%">

                                <div class="category__caption">
                                    <h3>ART</h3>
                                </div>
                            </a>
                        </div>
                        <div class="left__bottom">
                            <a href="">
                                <img src="assets/images/1-pxd5LHg51VRWzgGiOAaClg.jpeg" alt="TECH" width="100%">

                                <div class="category__caption">
                                    <h3>TECH MEETUP</h3>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="right">
                        <div class="right__top">
                            <a href="">
                                <img src="assets/images/Osaseye-Blog-❤_-Photo-by-@jidekola-NWcouple-NigerianWedding”.png" alt="WEDDING" width="100%">

                                <div class="category__caption">
                                    <h3>WEDDING</h3>
                                </div>
                            </a>
                        </div>
                        <div class="right__bottom">
                            <a href="">
                                <img src="assets/images/IMG_8876.jpg" alt="PARTY" width="100%">

                                <div class="category__caption">
                                    <h3>PARTY</h3>
                                </div>
                            </a>
                        </div>
                        <div class="right__bottom">
                            <a href="">
                                <img src="assets/images/goss-stadium-071812.jpg" alt="SPORT" width="100%">

                                <div class="category__caption">
                                    <h3>SPORT</h3>
                                </div>
                            </a>
                        </div>
                    </div>

                    </div>

                </div>
                <footer>
                    <h1 class="footbrand col-md-1">EVS</h1>
                </footer>
            </div> 
            
            
 </div>
