       <?php 
 // $current = strtotime(date("d-m-Y"));
 $current = strtotime(date("d-m-Y"));
 // $date    = strtotime("02-11-2017");    

 // $datediff = $date - $current;
 // $difference = floor($datediff/(60*60*24));
 // if($difference==0)
 // {
 //    echo 'today';
 // }
 // else if($difference > 1)
 // {
 //    echo 'Future Date';
 // }
 // else if($difference > 0)
 // {
 //    echo 'tomarrow';
 // }
 // else if($difference < -1)
 // {
 //    echo 'Long Back';
 // }
 // else
 // {
 //    echo 'yesterday';
 // }  
?>
<div class="header">
        <img class="embed-responsive header" src="assets/images/events-heavenly-header.jpg" alt="">
        
        <div class="header-content" ng-controller="homeController">
            <h0>FIND YOUR NEXT EXPERIENCE</h0>
            <div class="container  search-form-bg">
                <form class="search-form form-row">
                    <label for="inputEvent" class="sr-only">Search events or categories</label>
                    <input type="text" id="inputEvent" class="mx-2 form-item form-control" placeholder="Search events or categories" required>
                    <label for="inputLocation" class="sr-only">Location</label>
                    <input type="text" id="inputLocation" class="mx-2 form-control" placeholder="Location" required>
                    <label for="inputLocation" class="sr-only">Date</label>
                    <input type="text" id="inputDate" class="mx-2 form-control" placeholder="Date" required>

                    <span class="search-button">
                    <button class="btn btn-danger btn-search" type="submit">Search</button>
                    </span>
                </form>
            </div>
            <div class="container eventgrid">
              
                <div class="event-grid" ng-controller="FinanceController">
                    <div class="container text-center">
                        <form class="form-row popularForm">
                            <label for="inputLocation" class="popular">Popular Events in: </label>
                            <input type="text" id="inputLocation" class="searchLocation col-md-4 mx-2 form-control" placeholder="Enter city or Location" required>
                        </form>
                    </div>
                    <div class="container">
                        <div class="row card-group">
                          
                            <?php if(count($records)):?>
                                <?php foreach($records as $record):?>
                                    <!-- <?php print_r($record);?> -->
                                    <?php  $date    = strtotime($record->e_startdate);    
                                         $datediff = $date - strtotime(date("d-m-Y"));
                                         $difference = floor($datediff/(60*60*24));?>
                                         <?php  if($difference >=1):?>
            <div class="event-card">
    <a href="/eventsignal/events/e/<?php echo $record->event;?>/<?php echo $record->e_name;?>">
                    <div class="event-card__image">

<!-- <?php echo $record->e_image;?> -->
                        <img src="<?php echo $record->e_image;?>" alt="event picture" width="100%" class="emebed-responsive">
                    </div>
                    <div class="event-card__caption">
                        <div align="left">
                            <!-- $timestamp = "2013-09-30 01:16:06";
echo date("F jS, Y", strtotime($timestamp)); -->
                <span class="event-card__details"><?php $date =  $record->e_startdate;
                 echo date("F jS, Y", strtotime($date)) . " " . $record->e_starttime; ?>
             </span>
                    </div>
               <!-- $string= (strlen($string) > 13) ? substr($string,0,10).'...' : $string; -->
        <div class="event-card__name"> <span><?php $title = (strlen($record->e_name)) > 50 ? substr($record->e_name,0,45).'...' :$record->e_name; echo $title?></span>
         </div>
                        <div class="event-card__location"><?php echo $record->e_location;?></div>
                        <div class="line-down">
                        </div>
                        </a>
                       <!--  <div class="event-card__details" >
                          
                        </div> -->
                        <div class="line-down" align="center">
                            <a href="">
                             #tech #Blockchain
                         </a>
                        </div>
                    </div>
                
            </div>
                        <?php else:?>
                        <?php endif;?>
                        <?php endforeach;?>
                    <?php else:?>
                        <p> No Post Found</p>
                    <?php endif;?>
                        </div>
            

                        <div class="see-more">
                            <span class="padded"><a class="btn btn-outline-red" href="">SEE MORE</a> <span>    
                        </div>
                        </div>
                </div>
            </div>
            <br>
            <br>
            <div class="trending-categories container">
                <div class="big-headline text-center">
                    <h2>Browse by Categories</h2>
                </div>
                <div class="category-container">
                        <div class="left">
                            <div class="left__top">
                                <a href="">
                                    <img src="assets/images/event-music.jpg" alt="MUSIC" width="100%">

                                    <div class="category__caption">
                                        <h3>MUSIC</h3>
                            </div>
                            </a>
                        </div>
                        <div class="left__bottom">
                            <a href="">
                                <img src="assets/images/share_artsevent.jpg" alt="ART" width="100%">

                                <div class="category__caption">
                                    <h3>ART</h3>
                                </div>
                            </a>
                        </div>
                        <div class="left__bottom">
                            <a href="">
                                <img src="assets/images/1-pxd5LHg51VRWzgGiOAaClg.jpeg" alt="TECH" width="100%">

                                <div class="category__caption">
                                    <h3>TECH MEETUP</h3>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="right">
                        <div class="right__top">
                            <a href="">
                                <img src="assets/images/Osaseye-Blog-❤_-Photo-by-@jidekola-NWcouple-NigerianWedding”.png" alt="WEDDING" width="100%">

                                <div class="category__caption">
                                    <h3>WEDDING</h3>
                                </div>
                            </a>
                        </div>
                        <div class="right__bottom">
                            <a href="">
                                <img src="assets/images/IMG_8876.jpg" alt="PARTY" width="100%">

                                <div class="category__caption">
                                    <h3>PARTY</h3>
                                </div>
                            </a>
                        </div>
                        <div class="right__bottom">
                            <a href="">
                                <img src="assets/images/goss-stadium-071812.jpg" alt="SPORT" width="100%">

                                <div class="category__caption">
                                    <h3>SPORT</h3>
                                </div>
                            </a>
                        </div>
                    </div>

                    </div>

                </div>
                <footer>
                    <h1 class="footbrand col-md-1">EVS</h1>
                </footer>
            </div> 
            
            
 </div>

      
        </div>
                <script src="app/angular.js"></script>
            <script src="app/angular-route.js"></script>
             <script src="app/apps.js"></script>
            <script src="app/controllers.js"></script>
            <script src="assets/js/jquery-3.2.1.js"></script>
            
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/main.js"></script>
            

            <!-- Bootstrap JavaScript -->
            <script src="assets/js/bootstrap.js">
            </script>
</body>

</html>