
<div class="container-fluid backG">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="row">
                    <div class="col-md-12" id="googleMap">
                        <svg height="200" width="250">
                            <line x1="0" y1="0" x2="200" y2="200" style="stroke:rgb(110,110,110);stroke-width:2" />
                            <line x1="0" y1="200" x2="200" y2="0" style="stroke:rgb(110,110,110);stroke-width:2" />

                            <text fill="#ccc" font-size="35" font-family="Verdana" x="0" y="105">
                                Google Map</text>
                        </svg>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8 backGG">
                        <div class="row">
                            <div class="col-md-12 form-group sinput">
                                <input type="text" class="form-control" placeholder="Location">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn dropdown-toggle options btn-block" type="button" data-toggle="dropdown">CATEGORY
                                    <span class="glyphicon glyphicon-menu-down caty"></span></button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">MARRIAGE</a></li>
                                    <li><a href="#">HONEY MOON</a></li>
                                    <li><a href="#">FLEXING</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11 divide"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn dropdown-toggle options" type="button" data-toggle="dropdown">EVENT TYPE
                                    <span class="glyphicon glyphicon-menu-down eventT"></span></button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">BLABLA</a></li>
                                    <li><a href="#">LALA</a></li>
                                    <li><a href="#">GUGUGAGA</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11 divide"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn dropdown-toggle options" type="button" data-toggle="dropdown">DATE
                                    <span class="glyphicon glyphicon-menu-down date"></span></button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">BLABLA</a></li>
                                    <li><a href="#">LALA</a></li>
                                    <li><a href="#">GUGUGAGA</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-11 divide"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn dropdown-toggle options" type="button" data-toggle="dropdown">PRICE
                                    <span class="glyphicon glyphicon-menu-down price"></span></button>
                                <ul class="dropdown-menu">
                                    <li><a href="#">&dollar;100</a></li>
                                    <li><a href="#">&dollar;2000</a></li>
                                    <li><a href="#">&dollar;3000</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                          <div class="col-md-10">
                              <h1>Lagos,Nigeria Event For You</h1>
                          </div>
                      </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-5 col-md-offset-7">
                        <div class="btn-group">
                            <button type="button" class="btn btnpick btnpicked"><a href="#"> RELEVANCE </a></button>
                            <button type="button" class="btn btnpick"><a href="#"> DATE</a></button>
                        </div>
                    </div>
                </div>
                <div id="content" class="1-1">
                    <!-- looping starts ere -->
                    <?php if(count($records)):?>
                                <?php foreach($records as $record):?>
                                    <!-- <?php print_r($record);?> -->
                                    <?php  $date    = strtotime($record->e_startdate);    
                                         $datediff = $date - strtotime(date("d-m-Y"));
                                         $difference = floor($datediff/(60*60*24));?>
                                         <?php  if($difference >=1):?>
                    <a href="/eventsignal/events/e/<?php echo $record->event;?>/<?php echo $record->e_name;?>">
                <div class="row">
                    <div class="col-md-12 album">
                        <div class="row">
                            <div class="col-md-4 lunch">
                            </div>
                            <div class="col-md-8">
                                <h5 class="mediaDate">
                                     <?php $date =  $record->e_startdate;
                                         echo date("F jS, Y", strtotime($date)) . " " . $record->e_starttime; ?>
                                </h5>
                                <h4>
                                    <?php $title = (strlen($record->e_name)) > 50 ? substr($record->e_name,0,45).'...' :$record->e_name; echo $title?>
                                             
                                 </h4>
                                 <br>
                                 <h5 class="mediaDate">
                                   <?php echo $record->e_location;?>
                                </h5>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 luchTag">
                                <h5>FREE</h5>
                            </div>
                            <div class="col-md-8 pointer">
                                <div class="row">
                                    <div class="col-md-8 sellB">
                                        <a href="#"><span class="sell">#ScienceTech</span></a>
                                        <a href="#"><span class="sell">#Conference</span></a>
                                    </div>
                                    <div class="col-md-4 opty">
                                        <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                                        <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </a>
                <?php else:?>
                        <?php endif;?>
                        <?php endforeach;?>
                    <?php else:?>
                        <p> No Post Found</p>
                    <?php endif;?>
                <!-- looping ends ere -->

                </div>

                <div class="row">
                    <div class="col-md-7 col-md-offset-5">
                        <ul class="pagination pagination-md">
                            <li><a href="mapevent.html" class="contentUpdate">1</a></li>
                            <li><a href="#1-2" class="contentUpdate">2</a></li>
                            <li><a href="#1-3" class="contentUpdate">3</a></li>
                            <!--<li><a href="#1-4" class="contentUpdate">4</a></li>-->
                            <!--<li><a href="#1-5" class="contentUpdate">5</a></li>-->
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!--Footer begins-->
    <div class="row">
        <div class="col-md-12 footer" id="botts">
            <div class="row">
                <div class="col-md-4">
                    <div class="col-md-offset-1">
                        <span id="fsign">EVS</span><span id="copy">Copyright &copy; 2017 EVS</span>
                    </div>
                </div>
                <div class="col-md-8 elink">
                    <div id="got" class="col-md-offset-7">
                        <span class="ink"> <a href="" class="">FAQ</a></span>
                        <span class="ink"><a href="" class="">HELP</a></span>
                        <span class="ink"><a href="" class="">PRIVACY</a></span>
                        <span class="ink"><a href="" class="">TERMS</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Bach one begin-->
<div class="hiddenContent 1-2">
    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER Talkertiffff</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div><!--Bach one ends-->
<!--Bach Two begin-->
<div class="hiddenContent 1-3">
    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>FOOTBALL CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER TALK</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="row">
        <div class="col-md-12 album">
            <div class="row">
                <div class="col-md-4 lunch">
                </div>
                <div class="col-md-8">
                    <h5 class="mediaDate"></h5>
                    <h4>MUSIC CAREER Talker</h4>
                </div>
            </div>

            <div class="row">
                <div class="col-md-4 luchTag">
                    <h5>FREE</h5>
                </div>
                <div class="col-md-8 pointer">
                    <div class="row">
                        <div class="col-md-8 sellB">
                            <a href="#"><span class="sell">#Silicon</span></a>
                            <a href="#"><span class="sell">#Seleron</span></a>
                        </div>
                        <div class="col-md-4 opty">
                            <a href="#"><span class="glyphicon glyphicon-share sharer"></span></a>
                            <a href="#"><span class="glyphicon glyphicon-bookmark marker"></span></a>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div><!--Bach Two ends-->
<script src="js/index.js"></script>
<!-- </body>
</html>