
<!DOCTYPE html>
<html lang="en" ng-app="evs" ng-cloak>
 <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8" />
        <title>Eventsignal create a new event</title>

        <meta name="description" content="Common form elements and layouts" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

        <!-- bootstrap & fontawesome -->
         <link href="/eventsignal/assetz/css/style.css" rel="stylesheet">
        <!-- <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="assetz/css/bootstrap.min.css" /> -->
        <link rel="stylesheet" href="assetz/font-awesome/4.5.0/css/font-awesome.min.css" />

        <!-- page specific plugin styles -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/jquery-ui.custom.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/chosen.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-datepicker3.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-timepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/daterangepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-datetimepicker.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/bootstrap-colorpicker.min.css" />

        <!-- text fonts -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/fonts.googleapis.com.css" />

        <!-- ace styles -->
        <!-- <link rel="stylesheet" href="/eventsignal/assetz/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" /> -->
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace.unmin.css" class="ace-main-stylesheet" id="main-ace-style" />

        <!--[if lte IE 9]>
            <link rel="stylesheet" href="assetz/css/ace-part2.min.css" class="ace-main-stylesheet" />
        <![endif]-->
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace-skins.min.css" />
        <link rel="stylesheet" href="/eventsignal/assetz/css/ace-rtl.min.css" />


    </head>

<body class="no-skin">
                     <div class="space-24"></div>
                        <div class="space-24"></div>
                         <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2 ">
                            
                        <div class="hr hr-18 dotted hr-double"></div>
                               <div class="align-center">
                                  <h3>ACCOUNT OVERVIEW</h3>
                               </div> 
                        <div class="hr hr-18 dotted hr-double"></div>
                    </div>
                        <div class="space-24"></div> <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="space-24"></div>
                        <div class="col-sm-6">
                                        <div class="widget-box">
                                            <div class="widget-header widget-header-flat widget-header-small">
                                                <h5 class="widget-title">
                                                    <i class="ace-icon fa fa-signal"></i>
                                                    Events Created by You
                                                </h5>

                                                <div class="widget-toolbar no-border">
                                                    
                                                </div>
                                            </div>

                                            <div class="widget-body">
                                                <div class="widget-main">
                                                    <!-- <div id="piechart-placeholder"></div> -->

                                                    <div class="hr hr8 hr-double"></div>
                                                 
                                                    <div class="clearfix">
                                                        <div class="grid3">
                                                            <span class="grey">
                                                                <a href="">
                                                                <i class="ace-icon fa fa-bullhorn fa-2x blue"></i>
                                                                &nbsp; Active Events
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">100</h4>
                                                        </div>
                                                     
                                                        <div class="grid3">
                                                            <span class="grey">
                                                                <a href="">
                                                                <i class="ace-icon fa fa-calendar fa-2x purple"></i>
                                                                &nbsp; Past Events
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">100</h4>
                                                        </div>

                                                        
                                                        <div class="grid3">
                                                            <span class="yellow">
                                                                <a href="">

                                                                <i class="ace-icon fa fa-list fa-2x red"></i>
                                                                &nbsp; All Events
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">0</h4>
                                                        </div>
                                                    </div>
                                                </div><!-- /.widget-main -->
                                            </div><!-- /.widget-body -->
                                        </div><!-- /.widget-box -->
                                    </div><!-- /.col -->
                                    <div class="vspace-12-sm"></div>

                                <div class="col-sm-6">
                                        <div class="widget-box">
                                            <div class="widget-header widget-header-flat widget-header-small">
                                                <h5 class="widget-title green">
                                                    <i class="ace-icon fa fa-signal green"></i>
                                                    Registered Events
                                                </h5>

                                                <div class="widget-toolbar no-border">
                                                    
                                                </div>
                                            </div>

                                            <div class="widget-body">
                                                <div class="widget-main">
                                                    <!-- <div id="piechart-placeholder"></div> -->

                                                    <div class="hr hr8 hr-double"></div>
                                                 
                                                    <div class="clearfix">
                                                        <div class="grid3">
                                                            <span class="grey">
                                                                <a href="">

                                                                <i class="ace-icon fa fa-bullhorn fa-2x blue"></i>
                                                                &nbsp; Active Events
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">100</h4>
                                                        </div>
                                                     
                                                        <div class="grid3">
                                                            <span class="grey">
                                                                <a href="">

                                                                <i class="ace-icon fa fa-calendar fa-2x purple"></i>
                                                                &nbsp; Past Events
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">100</h4>
                                                        </div>

                                                        
                                                        <div class="grid3">
                                                            <span class="grey">
                                                                <a href="">

                                                                <i class="ace-icon fa fa-asterisk fa-2x red"></i>
                                                                &nbsp; Tickets
                                                            </a>
                                                            </span>
                                                            <h4 class="bigger pull-right">0</h4>
                                                        </div>
                                                    </div>
                                                </div><!-- /.widget-main -->
                                            </div><!-- /.widget-body -->
                                        </div><!-- /.widget-box -->
                                    </div><!-- /.col -->
</body>
</html>