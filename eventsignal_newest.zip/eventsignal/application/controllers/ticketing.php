<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticketing extends CI_Controller {

    public function index($id)
    {
        
        $this->load->view('header');
        $this->load->view('ticketing');
    }

    public function book_ticket($id){
        $event_id = $this->uri->segment(3, 0);
        $this->load->model('main');
        $records = $this->main->get_event_ticket_et($event_id);
        // var_dump($records);
        $this->load->view('header');
        $this->load->view('ticketing',['records' =>$records]);


    }

    



}
