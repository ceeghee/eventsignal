<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends CI_Controller {

    public function index()
    {
         // $product_id = $this->uri->segment(2, 0);
        // echo $product_id;
        // $this->load->view('header');
        echo "string";
        
        $this->load->view('header');
        $this->load->view('events');
    }

    public function e($id,$name){
        $event_id = $this->uri->segment(3, 0);
        $this->load->model('main');
        $records = $this->main->listEvents($event_id);
        $r2 = $this->main->get_event_ticket_et($event_id);
        // var_dump($r2);
        // print_r($records);
        // $this->load->view('header');
        // $this->load->view('home');
         $this->load->view('header');
        $this->load->view('events',['records' =>$records]);
    } 

    public function register(){
        echo "string";
    }  





}
