
<?php

class User extends CI_CONTROLLER{

	public function index(){

        $this->load->view('header');
        $this->load->view('users');
		
	}

	

   }