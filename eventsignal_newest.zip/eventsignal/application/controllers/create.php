<?php

class Create extends CI_Controller{

    public function index(){
       $this->authPage();


        $config=[
            'upload_path' => './uploads',
            'allowed_types' => 'jpg|png|jpeg',
        ];
        $this->load->library('upload',$config);

        if(isset($_POST['create_event'])){
                   $this->load->model('main');
                       $data=array(
                        'e_name'=>$this->input->post('title'),
                        'e_location'=>$this->input->post('location_1'),
                        'e_org_name' => $this->input->post('organizer'),
                        'e_startdate'=>$this->input->post('start_date'),
                        'e_enddate'=>$this->input->post('end_date'),
                        'e_type' => $this->input->post('event_type'),
                        'e_topic' => $this->input->post('event_topic'),
                        'e_starttime' => $this->input->post('start_time'),
                        'e_endtime' => $this->input->post('end_time'),
                        'e_desc' => $this->input->post('e_desc'),
                        'e_author' => $this->session->userdata('username')
                        // 'e_address_1' => $this->input->post('e_address_1')
                        // 'e_address_2' => $this->input->post('e_address_2')
                        // 'e_venue' => $this->input->post('e_venue')
                        // 'e_city' => $this->input->post('e_city')
                        // 'e_state' => $this->input->post('e_state')

                        
                        );
                       $ticket_data = array(
                            'ticket_title' => $this->input->post('ticket_title'),
                            'quantity' => $this->input->post('quantity'),
                            'ticket_description' => $this->input->post('ticket_description'),
                            'ticket_start' => $this->input->post('ticket_start'),
                            'ticket_end' => $this->input->post('ticket_end'),
                            'ticket_minimum' => $this->input->post('ticket_minimum'),
                            'ticket_maximum' => $this->input->post('ticket_maximum'),
                            'type' => $this->input->post('price'),
                            'ticket_start_time' => $this->input->post('ticket_start_time'),
                            'ticket_end_time' => $this->input->post('ticket_end_time'),
                            'tags' => $this->input->post('tags'),

                       );
                        // $_sid = $this->main->_singleEvent();
                        //     if($_sid){
                        //       echo "YUCK";
                        //     print_r($_sid);
                        //     echo "<br>";
                        //     echo $_sid[0]->event;
                        //     }
                       // if($this->main->create_event_ticket($ticket_data)){
                       //      echo "created tickets";
                       //  }
                       
                      // $this->upload->do_upload('e_image');
                      //  $info = $this->upload->data();
                      //  var_dump($info);
                       $main=array_filter($data);
                       $main2=array_filter($ticket_data);
                        if(count($main) >8 && $this->upload->do_upload('e_image')){
                           $info = $this->upload->data();
                            $image_path= ("uploads/".$info['raw_name'].$info['file_ext']);
                            $data['e_image'] = $image_path;
                          var_dump($main);
                          // echo count($main);
                            
                        if($this->main->create_event($data)){
                             $_sid = $this->main->_singleEvent();
                            if($_sid){
                                  if(count($main2)>7){
                                    $ticket_data['event_id'] = $_sid[0]->event;

                                      if($this->main->create_event_ticket($ticket_data)){
                                    $this->session->set_flashdata('response','Event Creation Was Successful');
                                      }
                                  }else{
                                     $this->session->set_flashdata('response','ENSURE ALL FIELDS ARE FILLED CORRECTLY');
                                  }
                            }
                            $this->session->set_flashdata('response','Event Creation Was Successful');
                        }
                      }else{
                       $this->session->set_flashdata('response','ENSURE ALL FIELDS ARE FILLED CORRECTLY');
                      }
        }
        // if($this->upload->do_upload()){
        //   $info = $this->upload->data();
        //   $image_path= base_url("uploads/".$info['raw_name'].$info['file_ext']);
        //   $this->load->model('main');
        //   if($this->main->create_event($data)){
        //       echo "Reg successfull";
        //   }else{
        //     echo "Failed";
        //   }
        // }
        // $this->load->view('header');
        
       $this->load->view('create');

    }



    public function authPage(){
        if (!isset($_SESSION['initiated'])) // to prevent session fixation
        {
            session_regenerate_id();
            $_SESSION['initiated'] = true;
        }


    
    if(!$this->session->userdata('userid'))
      {
           $_SESSION['create_repo']=true;
           header("location: http://localhost:8012/eventsignal/login");
           if(isset($_SESSION['gto_feedback'])){
                $_SESSION['gto_feedback']=false;
               }
      }
      // else{
      //       header("location: http://localhost:8012/eventsignal/login");

      // }
    }
}