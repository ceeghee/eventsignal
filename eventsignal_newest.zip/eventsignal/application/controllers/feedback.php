<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends CI_Controller {

    public function index()
    {
       $this->authPage();
        $this->load->model('main');
        $records = $this->main->getFeedBacks();
        if(isset($_POST['submitfeed'])){
                if($this->session->userdata('userid'))
                  {
                       
                $this->form_validation->set_rules("feedmessage", "FeedBack Message","trim|required|min_length[5]");

                $this->form_validation->set_rules("submit", "submit","trim|required");
                if($this->form_validation->run()==true){
                        $this->load->model('main');
                       //$data=$this->input->post();
                       //// $data['password']=md5($data['password']);
                        // $data['confirmpassword']=md5($data['confirmpassword']);
                       $data=array(
                        'feed_message'=>$this->input->post('feedmessage'),
                        'username' =>$this->session->userdata('username'),
                        'user_id' =>$this->session->userdata('userid'),
                        'timestamp'=>date('Y-m-h h:i:s')
                        );
                      if(isset($data)){
                        // flash sessions and redirect
                        if($this->main->saveFeed($data)){
                            $this->session->set_flashdata('feedresponse','FeedBack Sent Successfully');
                        }else{
                            $this->session->set_flashdata('feedresponse','Error Occured Try again');

                        }

                      }
                }else{
                    /*$this->load->view('header');
                    $this->load->view('Login');*/
                }
            }else{
                $_SESSION['gto_feedback']=true;
               header("location: http://localhost:8012/eventsignal/login");
               if(isset($_SESSION['create_repo'])){
                $_SESSION['create_repo']=false;
               }
           }
        }
        // print_r($records);
        $this->load->view('header');
        // var_dump( $records);
        $this->load->view('feedback', ['records' =>$records]);
        
    }

    public function authPage(){
        if (!isset($_SESSION['initiated'])) // to prevent session fixation
        {
            session_regenerate_id();
            $_SESSION['initiated'] = true;
        }


    
    // if(!$this->session->userdata('userid'))
    //   {
    //        $_SESSION['gto_feedback']=true;
    //        header("location: http://localhost:8012/eventsignal/login");
    //   }
      // else{
      //       header("location: http://localhost:8012/eventsignal/login");

      // }
    }


}
