<?php

class Signup extends CI_CONTROLLER{

    public function index(){
        $this->authPage();
        if(isset($_POST['signup'])){
                
                $this->form_validation->set_rules("password", "Password","trim|required|min_length[5]");

                $this->form_validation->set_rules("confirmpassword", "Confirm Password","trim|required|matches[password]");

                $this->form_validation->set_rules("username", "username","trim|required|min_length[5]|max_length[12]|callback_authUser");
                $this->form_validation->set_rules("email","Email","trim|required|valid_email|callback_authEmail");

                $this->form_validation->set_rules("submit", "submit","trim|required");
                if($this->form_validation->run()==true){
                        $this->load->model('main');
                       //$data=$this->input->post();
                       //// $data['password']=md5($data['password']);
                        // $data['confirmpassword']=md5($data['confirmpassword']);
                       $data=array(
                        'username'=>$this->input->post('username'),
                        'password'=>md5($this->input->post('password')),
                        'email'=>$this->input->post('email'),
                        'reg_date'=>date('Y-m-h h:i:s'),
                        'firstname'=> 'Null',
                        'lastname'=>'Null',
                        'country'=>'Nigeria'
                        );
                      if(isset($data)){
                        // flash sessions and redirect
                        if($this->main->signup($data)){
                            $this->session->set_flashdata('response','Registration Was Successful');
                        }else{
                            $this->session->set_flashdata('response','Registration Failed');

                        }

                      }
                }else{
                    /*$this->load->view('header');
                    $this->load->view('Login');*/
                }
        }
        $this->load->view('header');
        $this->load->view('signup');
    }

        public function authUser(){
            $username=$this->input->post('username');
             $this->load->model('main');
        if ($username!='' && $this->main->authUser($username)) {
    
            $this->form_validation->set_message('authUser','Username Already Exists');

            return false;
        } else {
            return true;
        }
        }

        public function authEmail(){
                $email=$this->input->post('email');
             $this->load->model('main');
        if ($email!='' && $this->main->authEmail($email)) {

            $this->form_validation->set_message('authEmail','Email Already Exists');

            return false;
        } else {
            return true;
        }

        }
        public function authPage(){
        if (!isset($_SESSION['initiated'])) // to prevent session fixation
        {
            session_regenerate_id();
            $_SESSION['initiated'] = true;
        }


    
            if($this->session->userdata('userid'))
              {
                    header("location: http://localhost:8012/eventsignal");
              }
            }
}