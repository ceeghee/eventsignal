	(function(){
 	var app=angular.module("evsControllers",[]);

	app.controller("mainController",mainOne);
		
		function mainOne(){
			vm = this;

			vm.title=true;
			
		}
	

	})();
	
			

			