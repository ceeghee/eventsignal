<!DOCTYPE html>
<html lang="" ng-app="evs">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Event Management System</title>

    <!-- Bootstrap CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">


</head>

<body>

    <!-- navigation bar begins here -->
    <nav class="navbar navbar-expand-md fixed-top ">
        <a class="navbar-brand mx-5" href="http://localhost:8012/eventsignal/">Eventsignal</a>
        <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
        <div class="collapse navbar-collapse mr-5" id="navbarCollapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                    <a class="nav-link" href="#">LEARN MORE</a>
                </li>
                <?php if($this->session->userdata('username')){ $username=$this->session->userdata('username')?>
                <li class="nav-item">
                    <a class="nav-link" href="#"><?php echo strtoupper($username);?></a>
                </li>

               <!--  <li class="nav-item">
                    <a class="btn btn-outline-red" href="login">Logout</a>
                </li> -->
                
            </ul>

            <span class="padded"><a class="btn btn-outline-red" href="logout">Logout</a> <span>
            <?php }else{?>
            <span class="padded"><a class="btn btn-outline-red" href="login">Login</a> <span>
            <?php }?>
            <span class="padded"><a class="btn btn-red" href="#">Create Event</a></span>
        </div>
    </nav>