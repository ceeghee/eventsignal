<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		// $this->output->cache(60); //caching a page
		$this->authPage();
		if(isset($_POST['login'])){
				
				$this->form_validation->set_rules("Email","Email","trim|required|valid_email");
				$this->form_validation->set_rules("Password", "Password","trim|required");
				//$this->form_validation->set_rules("submit", "submit","trim|required|callback_verifyUser");
				if($this->form_validation->run()==true){
					$this->load->model('main');
					$email=$this->input->post('Email');
					$password=md5($this->input->post('Password'));
					$user= $this->main->login($email,$password);
					
					if($user){
						$session_data=array(
								'userid'=>$user->user_id,
								'username'=>$user->username,
								'email'=>$user->email,
								'loggedin'=>true
							);
						$this->session->set_userdata($session_data);
						header("location: http://localhost:8012/eventsignal/");
						
					}else{
						$this->session->set_flashdata('loginresponse','Email or Password Incorrect');
					}
				}else{
					/*$this->load->view('header');
					$this->load->view('Login');*/
				}
    	}

    	$this->load->view('header');
		$this->load->view('login');
    	

	}


	public function verifyUser(){
		$email=$this->input->post('Email');
		$password=md5($this->input->post('Password'));
		$this->load->model('main');
		// $user= $this->main->login($email,$password);

		if ($email!='' && $password!='' && $this->main->login($email,$password)) {
			return true;
		} else {
			$this->form_validation->set_message('verifyUser','Email or Password Incorrect');
			return false;
		}
		
	}

	public function authPage(){
		if (!isset($_SESSION['initiated'])) // to prevent session fixation
	    {
	        session_regenerate_id();
	        $_SESSION['initiated'] = true;
	    }


    
    if($this->session->userdata('userid'))
      {
	    	header("location: http://localhost:8012/eventsignal/");
      }
    
    
		    // function redirect($DoDie=true)
		    // {
		    // 	header("location: http://localhost:8012/eventsignal/");
		    //   if($DoDie)
		    //   {
		    //     die();
		    //   }
		    // }
	}
}
