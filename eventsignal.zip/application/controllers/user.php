
<?php

class User extends CI_CONTROLLER{

	public function index(){

		
	}

	public function login(){
        if(isset($_POST['register'])){
		$this->load->model('main');
		//$rdata=json_decode(file_get_contents("php://input"));
		//$this->main->get_user_data('goodluck.ekene@gmail.com');
       
        redirect("Welcome/index","refresh");
    }
	}

    public function register(){

    }
}