<?php

class Logout extends CI_CONTROLLER{


    public function index(){
        session_start();
        session_unset();
        session_destroy();
        $_SESSION=array();

        header("location: http://localhost:8012/eventsignal/");

    }
}