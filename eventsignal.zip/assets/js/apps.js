	angular.module("myApp",[

		"myApp.controllers"

		]);

