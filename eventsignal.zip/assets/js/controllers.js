	
	angular.module("myApp.controllers",[])
			.controller('FinanceController', function($scope){

				$scope.salary=null;
				$scope.percentage=null;
				$scope.result=function(){
					return $scope.salary * $scope.percentage*0.01 ;
				};
			})
			.controller('GreetingController', function($scope){
				$scope.helloMessage=['Hello','Bonjour', 'kedu', 'Ciao','Halo'];
				$scope.greeting=$scope.helloMessage[0];
				$scope.now=new Date();
				$scope.getrmssg= function(){
					$scope.greeting = $scope.helloMessage[parseInt((Math.random()*$scope.helloMessage.length))]
				}
			
			});
			

			

		