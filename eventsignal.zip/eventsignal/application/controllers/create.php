<?php

class Create extends CI_Controller{

    public function index(){

       $this->authPage();

       $this->load->view('create');


    }



    public function authPage(){
        if (!isset($_SESSION['initiated'])) // to prevent session fixation
        {
            session_regenerate_id();
            $_SESSION['initiated'] = true;
        }


    
    if(!$this->session->userdata('userid'))
      {
           $_SESSION['create_repo']=true;
           header("location: http://localhost:8012/eventsignal/login");
      }
      // else{
      //       header("location: http://localhost:8012/eventsignal/login");

      // }
    }
}