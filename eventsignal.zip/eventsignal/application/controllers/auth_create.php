<?php

class Auth_Create extends CI_Controller{

    public function index(){

        $this->load->view('auth_create');
    }
}