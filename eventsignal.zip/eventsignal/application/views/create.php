<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Eventsignal create a new event</title>

		<meta name="description" content="Common form elements and layouts" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		 <link href="assets/css/style.css" rel="stylesheet">
	    <link href="assets/css/bootstrap.css" rel="stylesheet">
		<link rel="stylesheet" href="assetz/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assetz/font-awesome/4.5.0/css/font-awesome.min.css" />

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assetz/css/jquery-ui.custom.min.css" />
		<link rel="stylesheet" href="assetz/css/chosen.min.css" />
		<link rel="stylesheet" href="assetz/css/bootstrap-datepicker3.min.css" />
		<link rel="stylesheet" href="assetz/css/bootstrap-timepicker.min.css" />
		<link rel="stylesheet" href="assetz/css/daterangepicker.min.css" />
		<link rel="stylesheet" href="assetz/css/bootstrap-datetimepicker.min.css" />
		<link rel="stylesheet" href="assetz/css/bootstrap-colorpicker.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assetz/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assetz/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assetz/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
		<link rel="stylesheet" href="assetz/css/ace-skins.min.css" />
		<link rel="stylesheet" href="assetz/css/ace-rtl.min.css" />

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assetz/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
		<script src="assetz/js/ace-extra.min.js"></script>

		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assetz/js/html5shiv.min.js"></script>
		<script src="assetz/js/respond.min.js"></script>
		<![endif]-->
	</head>

	<body class="no-skin">
		<nav class="navbarz navbarz-expand-md fixed-top ">
        <a class="navbar-brand mx-5" href="http://localhost:8012/eventsignal/">Eventsignal</a>
        <button class="navbarz-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarzCollapse" aria-controls="navbarzCollapse" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbarz-toggler-icon"></span>
                </button>
        <div class="collapse navbarz-collapse mr-5" id="navbarzCollapse">
            <ul class="navbarz-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">BROWSE EVENTS</a>
                </li>
                <li class="nav-divide"></li>
                <li class="nav-item">
                </li>
                <?php if($this->session->userdata('username')){ $username=$this->session->userdata('username')?>
                <li class="nav-item">
                    <a class="nav-link" href="#"><?php echo strtoupper($username);?></a>
                </li>

               <!--  <li class="nav-item">
                    <a class="btn btn-outline-red" href="login">Logout</a>
                </li> -->
                
            </ul>

            <span class="padded"><a class="btn btn-red" href="logout">Logout</a> <span>
            <?php }else{?>
            <span class="padded"><a class="btn btn-red" href="login">Login</a> <span>
            <?php }?>
        </div>
    </nav>

		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			

			<div class="main-content">
				<div class="main-content-inner">
					

					<div class="page-content">
						

						<div class="page-header">
						<div class="space-24"></div>
						<div class="space-24"></div>

						<div class="hr hr-18 dotted hr-double"></div>
							
							<h1>
								Create An Event
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->
								<div>
								<h4 class="pink">
									<i class="ace-icon fa fa-hand-o-right green"></i>
									<a href="#modal-form" role="button" class="blue" data-toggle="modal">Event Details </a>
								</h4>
								<div class="hr hr-24"></div>
							</div>

				<form class="form-horizontal" role="form">
									
					<div class="form-group">
			<label class="col-sm-3 control-label no-padding-right" for="form-field-1"><strong> EVENT TITLE </strong></label>

						<div class="col-xs-12 col-sm-5">
							<!-- <input type="text" id="form-field-1" placeholder="Username" class="col-xs-10 col-sm-5" /> -->
							<textarea class="form-control limited" id="form-field-9" maxlength="75" placeholder="Give a short distinct name" required></textarea>
						</div>

					</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-1-1"><strong>LOCATION</strong> </label>

										<div class="col-sm-5">
											<textarea class="form-control" maxlength="70" placeholder="Specify where it's held"></textarea>
										</div>
										<i class="ace-icon fa fa-globe green"></i>
									<a href="#modal-form" role="button" class="blue" data-toggle="modal">Enter Address </a>
									</div>

									<div class="space-4"></div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right">STARTS</label>

										<div class="col-xs-12 col-sm-4">
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
													<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
													<span class="input-group-addon">
														<i class="fa fa-calendar bigger-110"></i>
													</span>
												</div>

											</div>
											<!-- <input type="text" class="col-sm-3 no-padding-right" value=""/> -->
										<!-- <label class="col-sm-3 control-label no-padding-right">ENDS</label> -->
											
											<div class="col-xs-8 col-sm-4">
												<div class="input-group">
											<select class="chosen-select form-control" id="form-field-select-3" data-placeholder="Pick a time">
																<option value="">  </option>
																<option value="AL">12:00am</option>
																<option value="AK">12:30am</option>
																<option value="AZ">1:00am</option>
																<option value="AR">1:30am</option>
																<option value="CA">2:00am</option>
																<option value="CO">2:30am</option>
																<option value="CT">3:00am</option>
																<option value="DE">3:30am</option>
																<option value="FL">4:00am</option>
																<option value="GA">4:30am</option>
																<option value="HI">5:00am</option>
																<option value="ID">5:30am</option>
																<option value="IL">6:00am</option>
																<option value="IN">6:30am</option>
																<option value="IA">7:00am</option>
																<option value="KS">7:30am</option>
																<option value="KY">8:00am</option>
																<option value="LA">8:30am</option>
																<option value="ME">9:00am</option>
																<option value="MD">9:30am</option>
																<option value="MA">10:00am</option>
																<option value="MI">10:30am</option>
																<option value="MN">11:00am</option>
																<option value="MS">11:30am</option>
																<option value="MO">12:00pm</option>
																<option value="MT">12:30pm</option>
																<option value="NE">1:00pm</option>
																<option value="NV">1:30pm</option>
																<option value="NH">2:00pm</option>
																<option value="NJ">2:30pm</option>
																<option value="NM">3:00pm</option>
																<option value="NY">3:30pm</option>
																<option value="NC">4:00pm</option>
																<option value="ND">4:30pm</option>
																<option value="OH">5:00pm</option>
																<option value="OK">5:30pm</option>
																<option value="OR">6:00pm</option>
																<option value="PA">6:30pm</option>
																<option value="RI">7:00pm</option>
																<option value="SC">7:30pm</option>
																<option value="SD">8:00pm</option>
																<option value="TN">8:30pm</option>
																<option value="TX">9:00pm</option>
																<option value="UT">9:30pm</option>
																<option value="VT">10:00pm</option>
																<option value="VA">10:30pm</option>
																<option value="WA">11:00pm</option>
																<option value="WV">11:30pm</option>
																
															</select>
													<span class="input-group-addon">
														<i class="fa fa-clock-o bigger-110"></i>
													</span>
												</div>
											</div>
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right">ENDS</label>

										<div class="col-xs-12 col-sm-4">
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
													<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
													<span class="input-group-addon">
														<i class="fa fa-calendar bigger-110"></i>
													</span>
												</div>

											</div>
											
											<div class="col-xs-8 col-sm-4">
												<div class="input-group">
													<select class="chosen-select form-control" id="form-field-select-3" data-placeholder="Pick a time">
																<option value="">  </option>
																<option value="AL">12:00am</option>
																<option value="AK">12:30am</option>
																<option value="AZ">1:00am</option>
																<option value="AR">1:30am</option>
																<option value="CA">2:00am</option>
																<option value="CO">2:30am</option>
																<option value="CT">3:00am</option>
																<option value="DE">3:30am</option>
																<option value="FL">4:00am</option>
																<option value="GA">4:30am</option>
																<option value="HI">5:00am</option>
																<option value="ID">5:30am</option>
																<option value="IL">6:00am</option>
																<option value="IN">6:30am</option>
																<option value="IA">7:00am</option>
																<option value="KS">7:30am</option>
																<option value="KY">8:00am</option>
																<option value="LA">8:30am</option>
																<option value="ME">9:00am</option>
																<option value="MD">9:30am</option>
																<option value="MA">10:00am</option>
																<option value="MI">10:30am</option>
																<option value="MN">11:00am</option>
																<option value="MS">11:30am</option>
																<option value="MO">12:00pm</option>
																<option value="MT">12:30pm</option>
																<option value="NE">1:00pm</option>
																<option value="NV">1:30pm</option>
																<option value="NH">2:00pm</option>
																<option value="NJ">2:30pm</option>
																<option value="NM">3:00pm</option>
																<option value="NY">3:30pm</option>
																<option value="NC">4:00pm</option>
																<option value="ND">4:30pm</option>
																<option value="OH">5:00pm</option>
																<option value="OK">5:30pm</option>
																<option value="OR">6:00pm</option>
																<option value="PA">6:30pm</option>
																<option value="RI">7:00pm</option>
																<option value="SC">7:30pm</option>
																<option value="SD">8:00pm</option>
																<option value="TN">8:30pm</option>
																<option value="TX">9:00pm</option>
																<option value="UT">9:30pm</option>
																<option value="VT">10:00pm</option>
																<option value="VA">10:30pm</option>
																<option value="WA">11:00pm</option>
																<option value="WV">11:30pm</option>
																
															</select>
													<span class="input-group-addon">
														<i class="fa fa-clock-o bigger-110"></i>
													</span>
												</div>
											</div>
										</div>
									</div>
									<div class="form-group">
									<div class="col-xs-12 col-sm-4">
											<div class="widget-box">
												<div class="widget-header">
													<h4 class="widget-title">Event Image</h4>

													<div class="widget-toolbar">
														<a href="#" data-action="collapse">
															<i class="ace-icon fa fa-chevron-up"></i>
														</a>

													</div>
												</div>

												<div class="widget-body">
													<div class="widget-main">
														<div class="form-group">
															<div class="col-xs-12">
														<input multiple="" type="file" id="id-input-file-3" />
															</div>
														</div>

														<label>
															<input type="checkbox" name="file-format" id="id-file-format" class="ace" />
															<span class="lbl"> Allow only images</span>
														</label>
													</div>
												</div>
											</div>
										</div><!-- Event Image Ending -->
									</div>
									<div class="form-group">
									<div class="col-sm-7"><!-- Mark down descxription starts -->

										<h4 class="header black">Event Description
											<span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="Include need-to-know information to make it easier for people to search for your event page and buy tickets once they're there.">?</span>
											
										</h4>

										<div class="widget-box widget-color-blue">
											<div class="widget-header widget-header-small">  </div>

											<div class="widget-body">
												<div class="widget-main no-padding">
													<textarea name="content" data-provide="markdown" data-iconlibrary="fa" rows="10">Event Description

														- list item 1
														- list item 2
														- list item 3</textarea>
												</div>

												<div class="widget-toolbox padding-4 clearfix">
													<div class="btn-group pull-left">
														<button class="btn btn-sm btn-info">
															<i class="ace-icon fa fa-times bigger-125"></i>
															Cancel
														</button>
													</div>

													<div class="btn-group pull-right">
														<button class="btn btn-sm btn-purple">
															<i class="ace-icon fa fa-floppy-o bigger-125"></i>
															Save
														</button>
													</div>
												</div>

											</div>
										</div>
									</div><!-- Entering Description -->
								</div>
									<div class="space-24"></div>
									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-2"><strong>ORGANIZER NAME</strong> </label>
										<div class="col-sm-9">
											<input type="text" id="form-field-2" placeholder="Who's organizing this event?" class="col-xs-10 col-sm-5" required />
											
										</div>
									</div>
			<div class="row">
			<div class="form-group">
				<div class="col-sm-7">
				<h4 class="header blue3">Create Event Tickets
					<span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="Include need-to-know information to make it easier for people to search for your event page and buy tickets once they're there.">?</span>
					
				</h4>
				</div>
				<div class="col-sm-7 widget-container-col" id="widget-container-col-10">
					<div class="widget-box" id="widget-box-10">
						<div class="widget-header widget-header-small">
							<h5 class="widget-title smaller">Create Tickets</h5>

							<div class="widget-toolbar no-border">
								<ul class="nav nav-tabs" id="myTab">
									<li class="active">
										<a data-toggle="tab" href="#free">FREE TICKET</a>
									</li>

									<li>
										<a data-toggle="tab" href="#paid">PAID TICKET</a>
									</li>
									<li>
										<a data-toggle="tab" href="#donation">DONATIONS</a>
									</li>
								</ul>
							</div>
						</div>

						<div class="widget-body">
							<div class="widget-main padding-6">
								<div class="tab-content">
									<div id="free" class="tab-pane in active">
										<div align="center">
										<span>Title</span>
										<input type="text" name="" data-rel="tooltip" data-trigger="enter" data-placement="top"  title="Give your ticket a name like: General Admission,Early bird, RSVP etc.".>

										<span>Quantity Available</span>
										<input type="number" name="" data-rel="tooltip" data-trigger="enter" data-placement="top"  title="Enter the total number of tickets available for this ticket type."
										placeholder="100">

										<span>Price</span>
										<strong><input readonly="" type="text"  id="form-input-readonly" value="FREE" /></strong>
									</div>

									<h4 class="header blue3">Settings
										
									</h4>
									<div class="space-24"></div>
									
							<div class="form-group">
								<label class="col-sm-2 control-label no-padding-right" for="form-field-1"><strong> Ticket description </strong></label>
						<div class="col-xs-12 col-sm-8">
							<textarea class="form-control" id="form-field-9" maxlength="70" placeholder="Tell your attendees more about this ticket"></textarea>
						</div>

							</div>

							<div class="form-group">
								<label class="col-sm-2 control-label no-padding-right" for="form-field-1"><strong> 
								Sales Channel </strong></label><span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="This is where attendees can register or buy this ticket">?</span>
						<div class="col-xs-12 col-sm-8">
							<select  class="form-control" id="form-field-select-4" data-placeholder="Select a Sales Channel">
							<option value="AL">Everywhere</option>
							<option value="AK">Online only</option>
							<option value="AZ">At the door only</option>
						</select>
						</div>

							</div>

							<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right">Ticket Sale Starts</label>

										<div class="col-xs-12 col-sm-6">
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
													<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
													<span class="input-group-addon">
														<i class="fa fa-calendar bigger-110"></i>
													</span>
												</div>

											</div>
											<!-- <input type="text" class="col-sm-3 no-padding-right" value=""/> -->
										<!-- <label class="col-sm-3 control-label no-padding-right">ENDS</label> -->
											
											<div class="col-xs-8 col-sm-4">
												<div class="input-group">
											<select class="chosen-select form-control" id="form-field-select-3" data-placeholder="Pick a time">
																<option value="">  </option>
																<option value="AL">12:00am</option>
																<option value="AK">12:30am</option>
																<option value="AZ">1:00am</option>
																<option value="AR">1:30am</option>
																<option value="CA">2:00am</option>
																<option value="CO">2:30am</option>
																<option value="CT">3:00am</option>
																<option value="DE">3:30am</option>
																<option value="FL">4:00am</option>
																<option value="GA">4:30am</option>
																<option value="HI">5:00am</option>
																<option value="ID">5:30am</option>
																<option value="IL">6:00am</option>
																<option value="IN">6:30am</option>
																<option value="IA">7:00am</option>
																<option value="KS">7:30am</option>
																<option value="KY">8:00am</option>
																<option value="LA">8:30am</option>
																<option value="ME">9:00am</option>
																<option value="MD">9:30am</option>
																<option value="MA">10:00am</option>
																<option value="MI">10:30am</option>
																<option value="MN">11:00am</option>
																<option value="MS">11:30am</option>
																<option value="MO">12:00pm</option>
																<option value="MT">12:30pm</option>
																<option value="NE">1:00pm</option>
																<option value="NV">1:30pm</option>
																<option value="NH">2:00pm</option>
																<option value="NJ">2:30pm</option>
																<option value="NM">3:00pm</option>
																<option value="NY">3:30pm</option>
																<option value="NC">4:00pm</option>
																<option value="ND">4:30pm</option>
																<option value="OH">5:00pm</option>
																<option value="OK">5:30pm</option>
																<option value="OR">6:00pm</option>
																<option value="PA">6:30pm</option>
																<option value="RI">7:00pm</option>
																<option value="SC">7:30pm</option>
																<option value="SD">8:00pm</option>
																<option value="TN">8:30pm</option>
																<option value="TX">9:00pm</option>
																<option value="UT">9:30pm</option>
																<option value="VT">10:00pm</option>
																<option value="VA">10:30pm</option>
																<option value="WA">11:00pm</option>
																<option value="WV">11:30pm</option>
																
															</select>
													<span class="input-group-addon">
														<i class="fa fa-clock-o bigger-110"></i>
													</span>
												</div>
											</div>
										</div>
									</div>	

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right">Ticket Sale Ends</label>

										<div class="col-xs-12 col-sm-6">
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
													<input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy" />
													<span class="input-group-addon">
														<i class="fa fa-calendar bigger-110"></i>
													</span>
												</div>

											</div>
											<!-- <input type="text" class="col-sm-3 no-padding-right" value=""/> -->
										<!-- <label class="col-sm-3 control-label no-padding-right">ENDS</label> -->
											
											<div class="col-xs-8 col-sm-4">
												<div class="input-group">
											<select class="chosen-select form-control" id="form-field-select-3" data-placeholder="Pick a time">
																<option value="">  </option>
																<option value="AL">12:00am</option>
																<option value="AK">12:30am</option>
																<option value="AZ">1:00am</option>
																<option value="AR">1:30am</option>
																<option value="CA">2:00am</option>
																<option value="CO">2:30am</option>
																<option value="CT">3:00am</option>
																<option value="DE">3:30am</option>
																<option value="FL">4:00am</option>
																<option value="GA">4:30am</option>
																<option value="HI">5:00am</option>
																<option value="ID">5:30am</option>
																<option value="IL">6:00am</option>
																<option value="IN">6:30am</option>
																<option value="IA">7:00am</option>
																<option value="KS">7:30am</option>
																<option value="KY">8:00am</option>
																<option value="LA">8:30am</option>
																<option value="ME">9:00am</option>
																<option value="MD">9:30am</option>
																<option value="MA">10:00am</option>
																<option value="MI">10:30am</option>
																<option value="MN">11:00am</option>
																<option value="MS">11:30am</option>
																<option value="MO">12:00pm</option>
																<option value="MT">12:30pm</option>
																<option value="NE">1:00pm</option>
																<option value="NV">1:30pm</option>
																<option value="NH">2:00pm</option>
																<option value="NJ">2:30pm</option>
																<option value="NM">3:00pm</option>
																<option value="NY">3:30pm</option>
																<option value="NC">4:00pm</option>
																<option value="ND">4:30pm</option>
																<option value="OH">5:00pm</option>
																<option value="OK">5:30pm</option>
																<option value="OR">6:00pm</option>
																<option value="PA">6:30pm</option>
																<option value="RI">7:00pm</option>
																<option value="SC">7:30pm</option>
																<option value="SD">8:00pm</option>
																<option value="TN">8:30pm</option>
																<option value="TX">9:00pm</option>
																<option value="UT">9:30pm</option>
																<option value="VT">10:00pm</option>
																<option value="VA">10:30pm</option>
																<option value="WA">11:00pm</option>
																<option value="WV">11:30pm</option>
																
															</select>
													<span class="input-group-addon">
														<i class="fa fa-clock-o bigger-110"></i>
													</span>
												</div>
											</div>
										</div>
									</div>	
										<div class="form-group">
									<label class="col-sm-3 control-label no-padding-right">Tickets allowed per order</label>

										<div class="col-xs-12 col-sm-6">
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
												<input class="form-control" placeholder="Minimum" type="text"  />
												
												</div>

											</div>
											<!-- <input type="text" class="col-sm-3 no-padding-right" value=""/> -->
										<!-- <label class="col-sm-3 control-label no-padding-right">ENDS</label> -->
											
											<div class="col-xs-8 col-sm-5">
												<div class="input-group">
												<input class="form-control" placeholder="Maximum" type="text"  />
												</div>
											</div>
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-3 control-label no-padding-right" for="form-field-tags">Tag this Event</label>

										<div class="col-sm-9">
											<div class="inline">
												<input type="text" name="tags" id="form-field-tags"  placeholder="Enter tags ..." />
											</div>
										</div>
									</div>
									</div><!-- tab-pane -->
									
										
									<div id="paid" class="tab-pane"><!-- Paid event yab space starts ere -->
										<p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid.</p>
									</div>

									<div id="donation" class="tab-pane"><!--donation event starts ere -->
										<p>Tab Space for donations</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

					<div class="form-group">
						<div class="form-group">
						<div class="col-sm-7">
						<h4 class="header blue3">Additional Settings
							<span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="Include need-to-know information to make it easier for people to search for your event page and buy tickets once they're there.">?</span>
							
						</h4>
					  </div>
						</div>

					<div class="form-group">
						<label class="col-sm-2 control-label no-padding-right" for="form-field-1"><strong> 
						EVENT TYPE </strong></label><span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="This is where attendees can register or buy this ticket">?</span>
				<div class="col-xs-12 col-sm-5">
					<select  class="form-control" id="form-field-select-4">
					<option value="" selected="selected">Select the type of event</option>
					<option value="19">Appearance or Signing</option>
					<option value="17">Attraction</option>
					<option value="18">Camp, Trip, or Retreat</option>
					<option value="9">Class, Training, or Workshop</option>
					<option value="6">Concert or Performance</option>
					<option value="1">Conference</option>
					<option value="4">Convention</option>
					<option value="8">Dinner or Gala</option>
					<option value="5">Festival or Fair</option>
					<option value="14">Game or Competition</option>
					<option value="10">Meeting or Networking Event</option>
					<option value="100">Other</option>
					<option value="11">Party or Social Gathering</option>
					<option value="15">Race or Endurance Event</option>
					<option value="12">Rally</option>
					<option value="7">Screening</option>
					<option value="2">Seminar or Talk</option>
					<option value="16">Tour</option>
					<option value="13">Tournament</option>
					<option value="3">Tradeshow, Consumer Show, or Expo</option>

				</select>
				</div>

					</div>

					<div class="form-group">
						<label class="col-sm-2 control-label no-padding-right" for="form-field-1"><strong> 
						EVENT TOPIC </strong></label><span class="help-button" data-rel="tooltip" data-trigger="hover" data-placement="top"  title="This is where attendees can register or buy this ticket">?</span>
				<div class="col-xs-12 col-sm-5">
					<select  class="form-control" id="form-field-select-4">
					<option value="" selected="selected">Select a topic</option>
					<option value="118">Auto, Boat &amp; Air</option>
					<option value="101">Business &amp; Professional</option>
					<option value="111">Charity &amp; Causes</option>
					<option value="113">Community &amp; Culture</option>
					<option value="115">Family &amp; Education</option>
					<option value="106">Fashion &amp; Beauty</option>
					<option value="104">Film, Media &amp; Entertainment</option>
					<option value="110">Food &amp; Drink</option>
					<option value="112">Government &amp; Politics</option>
					<option value="107">Health &amp; Wellness</option>
					<option value="119">Hobbies &amp; Special Interest</option>
					<option value="117">Home &amp; Lifestyle</option>
					<option value="103">Music</option>
					<option value="199">Other</option>
					<option value="105">Performing &amp; Visual Arts</option>
					<option value="114">Religion &amp; Spirituality</option>
					<option value="120">School Activities</option>
					<option value="102">Science &amp; Technology</option>
					<option value="116">Seasonal &amp; Holiday</option>
					<option value="108">Sports &amp; Fitness</option>
					<option value="109">Travel &amp; Outdoor</option>

				</select>
				</div>

					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label no-padding-right" for="form-field-1"><strong> 
						REMAINING TICKETS </strong></label>
					<div class="col-xs-12 col-sm-5">
						<div class="checkbox">
						<label class="block">
							<input name="form-field-checkbox" type="checkbox" class="ace input-lg" />
							<span class="lbl bigger-120"> Show the number of remaining tickets on your event listing</span>
						</label>
						</div>
					</div>

					</div>
					</div>

						<div id="modal-form" class="modal" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="blue bigger">Please fill the following form fields</h4>
											</div>

											<div class="modal-body">
												<div class="row">
													<div class="col-xs-12 col-sm-5">
														<div class="space"></div>

														<input type="file" />
													</div>

													<div class="col-xs-12 col-sm-7">
														<div class="form-group">
															<label for="form-field-select-3">Country</label>

															<div>
																<select class="chosen-select" data-placeholder="Choose a Country...">
																	<option value="">&nbsp;</option>
																	<option value="AL">Alabama</option>
																	<option value="AK">Alaska</option>
																	<option value="AZ">Arizona</option>
																	<option value="AR">Arkansas</option>
																	<option value="CA">California</option>
																	<option value="CO">Colorado</option>
																	<option value="CT">Connecticut</option>
																	<option value="DE">Delaware</option>
																	<option value="FL">Florida</option>
																	<option value="GA">Georgia</option>
																	<option value="HI">Hawaii</option>
																	<option value="ID">Idaho</option>
																	<option value="IL">Illinois</option>
																	<option value="IN">Indiana</option>
																	<option value="IA">Iowa</option>
																	<option value="KS">Kansas</option>
																	<option value="KY">Kentucky</option>
																	<option value="LA">Louisiana</option>
																	<option value="ME">Maine</option>
																	<option value="MD">Maryland</option>
																	<option value="MA">Massachusetts</option>
																	<option value="MI">Michigan</option>
																	<option value="MN">Minnesota</option>
																	<option value="MS">Mississippi</option>
																	<option value="MO">Missouri</option>
																	<option value="MT">Montana</option>
																	<option value="NE">Nebraska</option>
																	<option value="NV">Nevada</option>
																	<option value="NH">New Hampshire</option>
																	<option value="NJ">New Jersey</option>
																	<option value="NM">New Mexico</option>
																	<option value="NY">New York</option>
																	<option value="NG">Nigeria</option>
																	<option value="NC">North Carolina</option>
																	<option value="ND">North Dakota</option>
																	<option value="OH">Ohio</option>
																	<option value="OK">Oklahoma</option>
																	<option value="OR">Oregon</option>
																	<option value="PA">Pennsylvania</option>
																	<option value="RI">Rhode Island</option>
																	<option value="SC">South Carolina</option>
																	<option value="SD">South Dakota</option>
																	<option value="TN">Tennessee</option>
																	<option value="TX">Texas</option>
																	<option value="UT">Utah</option>
																	<option value="VT">Vermont</option>
																	<option value="VA">Virginia</option>
																	<option value="WA">Washington</option>
																	<option value="WV">West Virginia</option>
																	<option value="WI">Wisconsin</option>
																	<option value="WY">Wyoming</option>
																</select>
															</div>
														</div>


														<div class="form-group">
															<label for="form-field-username">Location</label>

															<div>
																<input type="text" id="form-field-username" placeholder="Enter the Venue's name" />
																<div class="space-4"></div>
																<input type="text" id="form-field-first" placeholder="Address" />
																<div class="space-4"></div>
																<input type="text" id="form-field-last" placeholder="Address 2"  />
																<div class="space-4"></div>
																<input type="text" id="form-field-first" placeholder="City" />
																<div class="space-4"></div>
																<input type="text" id="form-field-first" placeholder="State"  />
															</div>
															</div>
														</div>


														<!-- <div class="form-group">
															<label for="form-field-first">Address</label>

															<div>
																<input type="text" id="form-field-first" placeholder="Address" value="Alex" />
																<div class="space-4"></div>
																<input type="text" id="form-field-last" placeholder="Address 2" value="Doe" />
															</div>
														</div> -->
														<div class="space-4"></div>
<!-- 
														<div class="form-group">
															<label for="form-field-first">City</label>

															<div>
																<input type="text" id="form-field-first" placeholder="City" value="Alex" />
															</div>
														</div> -->
														<!-- <div class="space-1"></div>

														<div class="form-group">
															<label for="form-field-first">State</label>

															<div>
																<input type="text" id="form-field-first" placeholder="State" value="Alex" />
															</div>
														</div> -->
													</div>
												</div>
											</div>

											<div class="modal-footer">
												<button class="btn btn-sm" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Cancel
												</button>

												<button class="btn btn-sm btn-primary">
													<i class="ace-icon fa fa-check"></i>
													Save
												</button>
											</div>
										</div>
									</div>
					<!-- </div> -->
					
									

									<div class="space-4"></div>
								<div class="hr hr-18 dotted hr-double"></div>

								

									

									<div class="space-4"></div>

									

									<div class="space-4"></div>

									

									<div class="clearfix form-actions">
										<div class="col-md-offset-3 col-md-9">
											<button class="btn btn-success" type="submit">
												<i class="ace-icon fa fa-check bigger-110"></i>
												MAKE YOUR EVENT LIVE
											</button>
											&nbsp; &nbsp; &nbsp;
											<button class="btn btn-primary">
												<i class="ace-icon fa fa-save bigger-110"></i>
												SAVE
											</button>

											&nbsp; &nbsp; &nbsp;
											<button class="btn" type="reset">
												<i class="ace-icon fa fa-undo bigger-110"></i>
												RESET
											</button>
										</div>
									</div>

									
									
								</form>


								

							
							
								</div><!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->
					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

			

			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->

		<!-- basic scripts -->

		<!--[if !IE]> -->
		<script src="assetz/js/jquery-2.1.4.min.js"></script>

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assetz/js/jquery-1.11.3.min.js"></script>
<![endif]-->
		<script type="text/javascript">
			if('ontouchstart' in document.documentElement) document.write("<script src='assetz/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
		</script>
		<script src="assetz/js/bootstrap.min.js"></script>

		<!-- page specific plugin scripts -->

		<!--[if lte IE 8]>
		  <script src="assetz/js/excanvas.min.js"></script>
		<![endif]-->
		<script src="assetz/js/jquery-ui.custom.min.js"></script>
		<script src="assetz/js/jquery.ui.touch-punch.min.js"></script>
		<script src="assetz/js/chosen.jquery.min.js"></script>
		<script src="assetz/js/markdown.min.js"></script>
		<script src="assetz/js/bootstrap-markdown.min.js"></script>
		<script src="assetz/js/jquery.hotkeys.index.min.js"></script>
		<script src="assetz/js/bootstrap-wysiwyg.min.js"></script>
		<script src="assetz/js/bootbox.js"></script>
		<script src="assetz/js/spinbox.min.js"></script>
		<script src="assetz/js/bootstrap-datepicker.min.js"></script>
		<script src="assetz/js/bootstrap-timepicker.min.js"></script>
		<script src="assetz/js/moment.min.js"></script>
		<script src="assetz/js/daterangepicker.min.js"></script>
		<script src="assetz/js/bootstrap-datetimepicker.min.js"></script>
		<script src="assetz/js/bootstrap-colorpicker.min.js"></script>
		<script src="assetz/js/jquery.knob.min.js"></script>
		<script src="assetz/js/autosize.min.js"></script>
		<script src="assetz/js/jquery.inputlimiter.min.js"></script>
		<script src="assetz/js/jquery.maskedinput.min.js"></script>
		<script src="assetz/js/bootstrap-tag.min.js"></script>

		<!-- ace scripts -->
		<script src="assetz/js/ace-elements.min.js"></script>
		<script src="assetz/js/ace.min.js"></script>
		<script src="markdown.js"></script>
		<!-- inline scripts related to this page -->
		<script type="text/javascript">
			jQuery(function($) {
				$('#id-disable-check').on('click', function() {
					var inp = $('#form-input-readonly').get(0);
					if(inp.hasAttribute('disabled')) {
						inp.setAttribute('readonly' , 'true');
						inp.removeAttribute('disabled');
						inp.value="This text field is readonly!";
					}
					else {
						inp.setAttribute('disabled' , 'disabled');
						inp.removeAttribute('readonly');
						inp.value="This text field is disabled!";
					}
				});
			
			
				if(!ace.vars['touch']) {
					$('.chosen-select').chosen({allow_single_deselect:true}); 
					//resize the chosen on window resize
			
					$(window)
					.off('resize.chosen')
					.on('resize.chosen', function() {
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					}).trigger('resize.chosen');
					//resize chosen on sidebar collapse/expand
					$(document).on('settings.ace.chosen', function(e, event_name, event_val) {
						if(event_name != 'sidebar_collapsed') return;
						$('.chosen-select').each(function() {
							 var $this = $(this);
							 $this.next().css({'width': $this.parent().width()});
						})
					});
			
			
					$('#chosen-multiple-style .btn').on('click', function(e){
						var target = $(this).find('input[type=radio]');
						var which = parseInt(target.val());
						if(which == 2) $('#form-field-select-4').addClass('tag-input-style');
						 else $('#form-field-select-4').removeClass('tag-input-style');
					});
				}
			
			
				$('[data-rel=tooltip]').tooltip({container:'body'});
				$('[data-rel=popover]').popover({container:'body'});
			
				autosize($('textarea[class*=autosize]'));
				
				$('textarea.limited').inputlimiter({
					remText: '%n character%s remaining...',
					limitText: 'max allowed : %n.'
				});
			
				$.mask.definitions['~']='[+-]';
				$('.input-mask-date').mask('99/99/9999');
				$('.input-mask-phone').mask('(999) 999-9999');
				$('.input-mask-eyescript').mask('~9.99 ~9.99 999');
				$(".input-mask-product").mask("a*-999-a999",{placeholder:" ",completed:function(){alert("You typed the following: "+this.val());}});
			
			
			
				$( "#input-size-slider" ).css('width','200px').slider({
					value:1,
					range: "min",
					min: 1,
					max: 8,
					step: 1,
					slide: function( event, ui ) {
						var sizing = ['', 'input-sm', 'input-lg', 'input-mini', 'input-small', 'input-medium', 'input-large', 'input-xlarge', 'input-xxlarge'];
						var val = parseInt(ui.value);
						$('#form-field-4').attr('class', sizing[val]).attr('placeholder', '.'+sizing[val]);
					}
				});
			
				$( "#input-span-slider" ).slider({
					value:1,
					range: "min",
					min: 1,
					max: 12,
					step: 1,
					slide: function( event, ui ) {
						var val = parseInt(ui.value);
						$('#form-field-5').attr('class', 'col-xs-'+val).val('.col-xs-'+val);
					}
				});
			
			
				
				//"jQuery UI Slider"
				//range slider tooltip example
				$( "#slider-range" ).css('height','200px').slider({
					orientation: "vertical",
					range: true,
					min: 0,
					max: 100,
					values: [ 17, 67 ],
					slide: function( event, ui ) {
						var val = ui.values[$(ui.handle).index()-1] + "";
			
						if( !ui.handle.firstChild ) {
							$("<div class='tooltip right in' style='display:none;left:16px;top:-6px;'><div class='tooltip-arrow'></div><div class='tooltip-inner'></div></div>")
							.prependTo(ui.handle);
						}
						$(ui.handle.firstChild).show().children().eq(1).text(val);
					}
				}).find('span.ui-slider-handle').on('blur', function(){
					$(this.firstChild).hide();
				});
				
				
				$( "#slider-range-max" ).slider({
					range: "max",
					min: 1,
					max: 10,
					value: 2
				});
				
				$( "#slider-eq > span" ).css({width:'90%', 'float':'left', margin:'15px'}).each(function() {
					// read initial values from markup and remove that
					var value = parseInt( $( this ).text(), 10 );
					$( this ).empty().slider({
						value: value,
						range: "min",
						animate: true
						
					});
				});
				
				$("#slider-eq > span.ui-slider-purple").slider('disable');//disable third item
			
				
				$('#id-input-file-1 , #id-input-file-2').ace_file_input({
					no_file:'No File ...',
					btn_choose:'Choose',
					btn_change:'Change',
					droppable:false,
					onchange:null,
					thumbnail:false //| true | large
					//whitelist:'gif|png|jpg|jpeg'
					//blacklist:'exe|php'
					//onchange:''
					//
				});
				//pre-show a file name, for example a previously selected file
				//$('#id-input-file-1').ace_file_input('show_file_list', ['myfile.txt'])
			
			
				$('#id-input-file-3').ace_file_input({
					style: 'well',
					btn_choose: 'ADD EVENT IMAGE',
					btn_change: null,
					no_icon: 'ace-icon fa fa-image',
					droppable: true,
					thumbnail: 'fit'//large | fit
					//,icon_remove:null//set null, to hide remove/reset button
					/**,before_change:function(files, dropped) {
						//Check an example below
						//or examples/file-upload.html
						return true;
					}*/
					/**,before_remove : function() {
						return true;
					}*/
					,
					preview_error : function(filename, error_code) {
						//name of the file that failed
						//error_code values
						//1 = 'FILE_LOAD_FAILED',
						//2 = 'IMAGE_LOAD_FAILED',
						//3 = 'THUMBNAIL_FAILED'
						//alert(error_code);
					}
			
				}).on('change', function(){
					//console.log($(this).data('ace_input_files'));
					//console.log($(this).data('ace_input_method'));
				});
				
				
				//$('#id-input-file-3')
				//.ace_file_input('show_file_list', [
					//{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
					//{type: 'file', name: 'hello.txt'}
				//]);
			
				
				
			
				//dynamically change allowed formats by changing allowExt && allowMime function
				$('#id-file-format').removeAttr('checked').on('change', function() {
					var whitelist_ext, whitelist_mime;
					var btn_choose
					var no_icon
					if(this.checked) {
						btn_choose = "Drop images here or click to choose";
						no_icon = "ace-icon fa fa-picture-o";
			
						whitelist_ext = ["jpeg", "jpg", "png", "gif" , "bmp"];
						whitelist_mime = ["image/jpg", "image/jpeg", "image/png", "image/gif", "image/bmp"];
					}
					else {
						btn_choose = "Drop files here or click to choose";
						no_icon = "ace-icon fa fa-cloud-upload";
						
						whitelist_ext = null;//all extensions are acceptable
						whitelist_mime = null;//all mimes are acceptable
					}
					var file_input = $('#id-input-file-3');
					file_input
					.ace_file_input('update_settings',
					{
						'btn_choose': btn_choose,
						'no_icon': no_icon,
						'allowExt': whitelist_ext,
						'allowMime': whitelist_mime
					})
					file_input.ace_file_input('reset_input');
					
					file_input
					.off('file.error.ace')
					.on('file.error.ace', function(e, info) {
						//console.log(info.file_count);//number of selected files
						//console.log(info.invalid_count);//number of invalid files
						//console.log(info.error_list);//a list of errors in the following format
						
						//info.error_count['ext']
						//info.error_count['mime']
						//info.error_count['size']
						
						//info.error_list['ext']  = [list of file names with invalid extension]
						//info.error_list['mime'] = [list of file names with invalid mimetype]
						//info.error_list['size'] = [list of file names with invalid size]
						
						
						/**
						if( !info.dropped ) {
							//perhapse reset file field if files have been selected, and there are invalid files among them
							//when files are dropped, only valid files will be added to our file array
							e.preventDefault();//it will rest input
						}
						*/
						
						
						//if files have been selected (not dropped), you can choose to reset input
						//because browser keeps all selected files anyway and this cannot be changed
						//we can only reset file field to become empty again
						//on any case you still should check files with your server side script
						//because any arbitrary file can be uploaded by user and it's not safe to rely on browser-side measures
					});
					
					
					/**
					file_input
					.off('file.preview.ace')
					.on('file.preview.ace', function(e, info) {
						console.log(info.file.width);
						console.log(info.file.height);
						e.preventDefault();//to prevent preview
					});
					*/
				
				});
			
				$('#spinner1').ace_spinner({value:0,min:0,max:200,step:10, btn_up_class:'btn-info' , btn_down_class:'btn-info'})
				.closest('.ace-spinner')
				.on('changed.fu.spinbox', function(){
					//console.log($('#spinner1').val())
				}); 
				$('#spinner2').ace_spinner({value:0,min:0,max:10000,step:100, touch_spinner: true, icon_up:'ace-icon fa fa-caret-up bigger-110', icon_down:'ace-icon fa fa-caret-down bigger-110'});
				$('#spinner3').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus bigger-110', icon_down:'ace-icon fa fa-minus bigger-110', btn_up_class:'btn-success' , btn_down_class:'btn-danger'});
				$('#spinner4').ace_spinner({value:0,min:-100,max:100,step:10, on_sides: true, icon_up:'ace-icon fa fa-plus', icon_down:'ace-icon fa fa-minus', btn_up_class:'btn-purple' , btn_down_class:'btn-purple'});
			
				//$('#spinner1').ace_spinner('disable').ace_spinner('value', 11);
				//or
				//$('#spinner1').closest('.ace-spinner').spinner('disable').spinner('enable').spinner('value', 11);//disable, enable or change value
				//$('#spinner1').closest('.ace-spinner').spinner('value', 0);//reset to 0
			
			
				//datepicker plugin
				//link
				$('.date-picker').datepicker({
					autoclose: true,
					todayHighlight: true
				})
				//show datepicker when clicking on the icon
				.next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
			
				//or change it into a date range picker
				$('.input-daterange').datepicker({autoclose:true});
			
			
				//to translate the daterange picker, please copy the "examples/daterange-fr.js" contents here before initialization
				$('input[name=date-range-picker]').daterangepicker({
					'applyClass' : 'btn-sm btn-success',
					'cancelClass' : 'btn-sm btn-default',
					locale: {
						applyLabel: 'Apply',
						cancelLabel: 'Cancel',
					}
				})
				.prev().on(ace.click_event, function(){
					$(this).next().focus();
				});
			
			
				$('#timepicker1').timepicker({
					minuteStep: 1,
					showSeconds: true,
					showMeridian: false,
					disableFocus: true,
					icons: {
						up: 'fa fa-chevron-up',
						down: 'fa fa-chevron-down'
					}
				}).on('focus', function() {
					$('#timepicker1').timepicker('showWidget');
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
				
			
				
				if(!ace.vars['old_ie']) $('#date-timepicker1').datetimepicker({
				 // format: 'MM/DD/YYYY h:mm:ss A',//use this option to display seconds
				 icons: {
					time: 'fa fa-clock-o',
					date: 'fa fa-calendar',
					up: 'fa fa-chevron-up',
					down: 'fa fa-chevron-down',
					previous: 'fa fa-chevron-left',
					next: 'fa fa-chevron-right',
					today: 'fa fa-arrows ',
					clear: 'fa fa-trash',
					close: 'fa fa-times'
				 }
				}).next().on(ace.click_event, function(){
					$(this).prev().focus();
				});
				
			
				$('#colorpicker1').colorpicker();
				//$('.colorpicker').last().css('z-index', 2000);//if colorpicker is inside a modal, its z-index should be higher than modal'safe
			
				$('#simple-colorpicker-1').ace_colorpicker();
				//$('#simple-colorpicker-1').ace_colorpicker('pick', 2);//select 2nd color
				//$('#simple-colorpicker-1').ace_colorpicker('pick', '#fbe983');//select #fbe983 color
				//var picker = $('#simple-colorpicker-1').data('ace_colorpicker')
				//picker.pick('red', true);//insert the color if it doesn't exist
			
			
				$(".knob").knob();
				
				
				var tag_input = $('#form-field-tags');
				try{
					tag_input.tag(
					  {
						placeholder:tag_input.attr('placeholder'),
						//enable typeahead by specifying the source array
						source: ace.vars['US_STATES'],//defined in ace.js >> ace.enable_search_ahead
						/**
						//or fetch data from database, fetch those that match "query"
						source: function(query, process) {
						  $.ajax({url: 'remote_source.php?q='+encodeURIComponent(query)})
						  .done(function(result_items){
							process(result_items);
						  });
						}
						*/
					  }
					)
			
					//programmatically add/remove a tag
					var $tag_obj = $('#form-field-tags').data('tag');
					$tag_obj.add('Programmatically Added');
					
					var index = $tag_obj.inValues('some tag');
					$tag_obj.remove(index);
				}
				catch(e) {
					//display a textarea for old IE, because it doesn't support this plugin or another one I tried!
					tag_input.after('<textarea id="'+tag_input.attr('id')+'" name="'+tag_input.attr('name')+'" rows="3">'+tag_input.val()+'</textarea>').remove();
					//autosize($('#form-field-tags'));
				}
				
				
				/////////
				$('#modal-form input[type=file]').ace_file_input({
					style:'well',
					btn_choose:'Drop files here or click to choose',
					btn_change:null,
					no_icon:'ace-icon fa fa-cloud-upload',
					droppable:true,
					thumbnail:'large'
				})
				
				//chosen plugin inside a modal will have a zero width because the select element is originally hidden
				//and its width cannot be determined.
				//so we set the width after modal is show
				$('#modal-form').on('shown.bs.modal', function () {
					if(!ace.vars['touch']) {
						$(this).find('.chosen-container').each(function(){
							$(this).find('a:first-child').css('width' , '210px');
							$(this).find('.chosen-drop').css('width' , '210px');
							$(this).find('.chosen-search input').css('width' , '200px');
						});
					}
				})
				/**
				//or you can activate the chosen plugin after modal is shown
				//this way select element becomes visible with dimensions and chosen works as expected
				$('#modal-form').on('shown', function () {
					$(this).find('.modal-chosen').chosen();
				})
				*/
			
				
				
				$(document).one('ajaxloadstart.page', function(e) {
					autosize.destroy('textarea[class*=autosize]')
					
					$('.limiterBox,.autosizejs').remove();
					$('.daterangepicker.dropdown-menu,.colorpicker.dropdown-menu,.bootstrap-datetimepicker-widget.dropdown-menu').remove();
				});
			
			});
		</script>
	</body>
</html>
