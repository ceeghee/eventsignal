	
	var app = angular.module("evs.controllers",[]);
			app.controller('FinanceController', function($scope){

				$scope.salary='Goodluck';
				$scope.percentage=null;
				$scope.result=function(){
					return $scope.salary * $scope.percentage*0.01 ;
				};
			})
			app.controller('GreetingController', function($scope){
				$scope.helloMessage=['Hello','Bonjour', 'kedu', 'Ciao','Halo'];
				$scope.greeting=$scope.helloMessage[0];
				$scope.now=new Date();
				$scope.getrmssg= function(){
					$scope.greeting = $scope.helloMessage[parseInt((Math.random()*$scope.helloMessage.length))]
				}
			
			});


			app.controller("startController",function($scope,$http){


				$scope.getDetails=function(){
					$http.post('user/user_details',{'email': $scope.email})
					.success=(function(data){

						$scope.msg=data;
					})

				}
			});

			app.controller("loginController",function($scope){


				$scope.welcome="Search";
			});


			
	/*angular.module("myApp.controllers",[])*/
			

		